MARIGOLD NO-PHP VERSION

Open index.html to start the app.

This version does not need PHP, MySQL, XAMPP, MAMP, or phpMyAdmin.
It stores users and bookings in the browser using localStorage.

Default accounts:

admin / admin123
secretary / secretary123
user / user123

Important:
Data is saved only in the browser and computer where you use it.
If you clear browser storage, the app resets to the default accounts.
