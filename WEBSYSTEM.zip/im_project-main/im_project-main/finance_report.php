<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once 'classes/Auth.php';
require_once 'classes/BookingManager.php';
$auth = new Auth();
$roleObj = null;
require_once 'classes/Role.php';
// Permission: finance report
if (!$auth->isLoggedIn()) {
    header('Location: login.php');
    exit;
}
$roleObj = new Role($auth->getRole());
if (!$roleObj->canViewFinanceReport()) {
    header('Location: login.php');
    exit;
}
$manager = new BookingManager();

// AJAX: update payment status
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_paid') {
    $id = isset($_POST['booking_id']) ? (int)$_POST['booking_id'] : 0;
    $isPaid = isset($_POST['is_paid']) ? (int)$_POST['is_paid'] : 0;
    if ($id > 0) {
        $success = $manager->updateBookingPaid($id, $isPaid);
        header('Content-Type: application/json');
        echo json_encode(['success' => $success]);
        exit;
    }
}

$today = new DateTime('now', new DateTimeZone('Asia/Manila'));
$currentMonth = (int)$today->format('n');
$currentYear = (int)$today->format('Y');
$viewMonth = isset($_GET['month']) ? (int)$_GET['month'] : $currentMonth;
$viewYear = isset($_GET['year']) ? (int)$_GET['year'] : $currentYear;

$all = $manager->getBookings();
$bookings = [];
foreach ($all as $b) {
    $d = DateTime::createFromFormat('Y-m-d', $b->date);
    if (!$d) continue;
    if ((int)$d->format('n') === $viewMonth && (int)$d->format('Y') === $viewYear) {
        $bookings[] = $b;
    }
}
// Group bookings by date
$byDate = [];
foreach ($bookings as $bk) {
    $byDate[$bk->date][] = $bk;
}

$expectedTotal = 0.0;
$collectedTotal = 0.0;
// Totals (pricing computed in Booking)
foreach ($bookings as $bk) {
    $expectedTotal += (float)$bk->totalPrice;
    if (!empty($bk->isPaid) && (int)$bk->isPaid === 1) {
        $collectedTotal += (float)$bk->totalPrice;
    }
}
$outstanding = $expectedTotal - $collectedTotal;

// Pagination
$perPage = 10;
$totalRows = count($bookings);
$totalPages = max(1, (int)ceil($totalRows / $perPage));
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
if ($page > $totalPages) $page = $totalPages;
$startIndex = ($page - 1) * $perPage;
$pagedBookings = array_slice($bookings, $startIndex, $perPage);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Finance Report - <?php echo htmlspecialchars(date('F Y', mktime(0,0,0,$viewMonth,1,$viewYear))); ?></title>
    <link rel="stylesheet" href="assets/css/styles.css">
    <style>
        :root{--primary-color:#1b3a0d;--secondary-color:#2d5016;--light-bg:#fff}
        body{font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial; margin:0; background:#f6f7f8; color:var(--primary-color)}
        .page-header{display:flex;align-items:center;justify-content:space-between;padding:16px 40px;background:var(--secondary-color);color:#fff}
        .header-logo{font-weight:700}
        .container{max-width:1200px;margin:28px auto;padding:20px;background:var(--light-bg);border-radius:10px;box-shadow:0 8px 24px rgba(0,0,0,0.06);}
        /* ensure footer does not overlap content */
        main.container { padding-bottom:160px; }
        /* make the table larger and more readable */
        table{width:100%;border-collapse:collapse;margin-top:12px;font-size:0.95rem}
        th,td{padding:10px 14px;border-bottom:1px solid #eee;text-align:left}
        th{background:#f7f9f7;color:var(--secondary-color);font-weight:800}
        /* Big totals section */
        .totals{margin-top:24px;display:flex;gap:20px;justify-content:center;align-items:center;padding:24px;background:linear-gradient(135deg, #f0f8e8 0%, #e8f5e0 100%);border-radius:12px;border:2px solid var(--secondary-color)}
        .totals > div{flex:1;text-align:center;padding:12px}
        .totals > div strong{display:block;font-size:0.9rem;color:var(--secondary-color);margin-bottom:6px}
        .totals > div .amount{display:block;font-size:2rem;font-weight:900;color:var(--primary-color)}
        .btn-primary-pill{background:var(--secondary-color);color:#fff;padding:8px 14px;border-radius:20px;text-decoration:none;font-weight:700}
        /* Editable status cell */
        .status{cursor:pointer;padding:5px 10px;border-radius:12px;font-weight:700;font-size:0.85rem;display:inline-block;transition:opacity 0.2s}
        .status:hover{opacity:0.7}
        .status-paid { background:#d4edda; color:#155724; }
        .status-partial { background:#fff3cd; color:#856404; }
        .status-unpaid { background:#f8d7da; color:#721c24; }
        .status-free { background:#e6f4ea; color:#0b5f2b; }
        /* Payment edit modal */
        .edit-payment-modal{position:fixed;inset:0;background:rgba(0,0,0,0.6);display:none;align-items:center;justify-content:center;z-index:9999}
        .edit-payment-modal.open{display:flex}
        .edit-payment-box{background:#fff;border-radius:12px;box-shadow:0 20px 60px rgba(0,0,0,0.3);padding:24px;max-width:400px;width:100%}
        .edit-payment-box h3{margin-top:0;color:var(--secondary-color)}
        .edit-payment-box label{display:block;margin-top:12px;font-weight:700}
        .edit-payment-box input{width:100%;padding:8px;margin-top:4px;border:1px solid #ccc;border-radius:6px;box-sizing:border-box}
        .edit-payment-box .btn-group{display:flex;gap:8px;margin-top:18px}
        .edit-payment-box button{flex:1;padding:8px 12px;border:none;border-radius:6px;font-weight:700;cursor:pointer}
        .edit-payment-box .btn-save{background:var(--secondary-color);color:#fff}
        .edit-payment-box .btn-cancel{background:#ddd;color:#333}
        /* Pin footer to bottom for report page */
        .site-footer { position: fixed; left:0; right:0; bottom:0; z-index:1000; }
        /* Ensure main container above fixed footer on small screens */
        @media (max-width: 760px) {
            main.container { padding-bottom:220px; }
        }
    </style>
</head>
<body class="no-court-bg">
    <div class="page-header">
        <div class="header-left"></div>
        <div class="header-logo">MARIGOLD SUBDIVISION COURT BOOKING</div>
        <div class="header-right">
            <span style="font-weight:600;color:#fff">Admin: <strong><?php echo htmlspecialchars($auth->getUsername()); ?></strong></span>
            <a href="dashboard_admin.php" class="header-link">&larr; Back</a>
            <a href="logout.php" class="header-link">🚪 Logout</a>
        </div>
    </div>

    <main class="container">
        <h2>Monthly Finance Report — <?php echo htmlspecialchars(date('F Y', mktime(0,0,0,$viewMonth,1,$viewYear))); ?></h2>
        <form method="get" style="margin-top:8px;display:flex;gap:8px;align-items:center">
            <label for="month">Month</label>
            <select id="month" name="month">
                <?php for ($m=1;$m<=12;$m++): ?>
                    <option value="<?php echo $m; ?>" <?php if ($m==$viewMonth) echo 'selected'; ?>><?php echo date('F', mktime(0,0,0,$m,1,2000)); ?></option>
                <?php endfor; ?>
            </select>
            <label for="year">Year</label>
            <input id="year" name="year" type="number" value="<?php echo $viewYear; ?>" style="width:100px">
            <button class="btn-primary-pill" type="submit">View</button>
        </form>

        <?php if (empty($bookings)): ?>
            <p style="margin-top:18px;color:#666">No bookings found for this month.</p>
        <?php else: ?>
            <table aria-describedby="finance-summary">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Name</th>
                        <th>Time</th>
                        <th>Rate/hr</th>
                        <th>Total</th>
                        <th>Paid</th>
                        <th>Status</th>
                        <th>Electricity</th>
                        <th>Homeowner</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($pagedBookings as $r): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($r->date); ?></td>
                        <td><?php echo htmlspecialchars($r->name); ?></td>
                        <td><?php echo htmlspecialchars($r->startTime . ' - ' . $r->endTime); ?></td>
                        <?php
                            // Compute rate/hr breakdown
                            $dtBooking = DateTime::createFromFormat('Y-m-d', $r->date);
                            $isSaturday = $dtBooking && $dtBooking->format('w') == 6;
                            $morningStartTime = $isSaturday ? '05:00' : '08:00';
                            $startTs = strtotime($r->date . ' ' . $r->startTime);
                            $endTs = strtotime($r->date . ' ' . $r->endTime);
                            $morningStartTs = strtotime($r->date . ' ' . $morningStartTime);
                            $eveningStartTs = strtotime($r->date . ' 17:00');
                            $nightEndTs = strtotime($r->date . ' 22:00');

                            $morningOverlap = max(0, min($endTs, $eveningStartTs) - max($startTs, $morningStartTs));
                            $eveningOverlap = max(0, min($endTs, $nightEndTs) - max($startTs, $eveningStartTs));
                            $morningHours = (int)($morningOverlap / 3600);
                            $eveningHours = (int)($eveningOverlap / 3600);

                            $parts = [];
                            if (!empty($r->isHomeowner) && (int)$r->isHomeowner === 1) {
                                // Homeowner pricing: morning free, evening 200/hr
                                if ($morningHours > 0) {
                                    $parts[] = sprintf('Morning (%s-17:00): Free × %dh', $morningStartTime, $morningHours);
                                }
                                if ($eveningHours > 0) {
                                    $parts[] = sprintf('Evening (17:00-22:00): ₱%d/hr × %dh (electricity included)', 200, $eveningHours);
                                }
                                if (empty($parts)) $parts[] = 'No billable hours';
                                $rateDisplay = implode('<br>', $parts);
                            } else {
                                $morningRate = 75;
                                $eveningRate = 250;
                                if ($morningHours > 0) {
                                    $mRateWithElec = $morningRate + ((!empty($r->electricity) && (int)$r->electricity === 1) ? 25 : 0);
                                    $parts[] = sprintf('Morning (%s-17:00): ₱%d/hr × %dh', $morningStartTime, $mRateWithElec, $morningHours);
                                }
                                if ($eveningHours > 0) {
                                    $parts[] = sprintf('Evening (17:00-22:00): ₱%d/hr × %dh', $eveningRate, $eveningHours);
                                }
                                if (empty($parts)) $parts[] = 'No billable hours';
                                $rateDisplay = implode('<br>', $parts);
                            }
                        ?>
                        <td><?php echo $rateDisplay; ?></td>
                        <td><?php echo number_format($r->totalPrice,2); ?></td>
                        <td><?php echo (!empty($r->isPaid) && (int)$r->isPaid === 1) ? 'Yes' : 'No'; ?></td>
                        <?php
                            $totalAmt = (float)$r->totalPrice;
                            if ($totalAmt <= 0) {
                                $status = 'Free';
                            } elseif (!empty($r->isPaid) && (int)$r->isPaid === 1) {
                                $status = 'Paid';
                            } else {
                                $status = 'Unpaid';
                            }
                        ?>
                        <td><span class="status status-<?php echo strtolower($status); ?>" onclick="openPaymentModal(<?php echo $r->id; ?>, <?php echo $r->totalPrice; ?>, <?php echo (!empty($r->isPaid) && (int)$r->isPaid === 1) ? 1 : 0; ?>)" title="Click to edit payment"><?php echo $status; ?></span></td>
                        <td><?php echo $r->electricity ? 'Yes' : 'No'; ?></td>
                        <td><?php echo $r->isHomeowner ? 'Yes' : 'No'; ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>

            <?php if ($totalPages > 1): ?>
            <div style="margin-top:12px;display:flex;justify-content:center;align-items:center;gap:12px;"> 
                <?php if ($page > 1): ?>
                    <a class="btn-primary-pill" href="?month=<?php echo $viewMonth; ?>&year=<?php echo $viewYear; ?>&page=<?php echo $page-1; ?>">&laquo; Prev</a>
                <?php endif; ?>
                <div style="font-weight:700;color:var(--secondary-color);">Page <?php echo $page; ?> of <?php echo $totalPages; ?></div>
                <?php if ($page < $totalPages): ?>
                    <a class="btn-primary-pill" href="?month=<?php echo $viewMonth; ?>&year=<?php echo $viewYear; ?>&page=<?php echo $page+1; ?>">Next &raquo;</a>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <div class="totals" id="finance-summary">
                <div>
                    <strong>Expected Revenue</strong>
                    <span class="amount">₱<?php echo number_format($expectedTotal,2); ?></span>
                </div>
                <div>
                    <strong>Collected</strong>
                    <span class="amount">₱<?php echo number_format($collectedTotal,2); ?></span>
                </div>
                <div>
                    <strong>Outstanding</strong>
                    <span class="amount">₱<?php echo number_format($outstanding,2); ?></span>
                </div>
            </div>
        <?php endif; ?>
    </main>

    <footer class="site-footer" role="contentinfo">
        <div class="footer-left">
            <img src="assets/logo.png" alt="Marigold Logo">
            <div>
                <div class="sub-name">Marigold Subdivision</div>
                <div class="address">Phase 1 Marigold Subdivision Burgos, Rodriguez, Rizal.</div>
                <div class="contact">Contact: <a href="tel:0962620781" style="color:var(--primary-color);text-decoration:none;">0962620781</a></div>
            </div>
        </div>
        <div class="footer-links" aria-label="Footer links">
            <!-- Footer links intentionally omitted for admin report -->
        </div>
    </footer>

    <!-- Payment Edit Modal -->
    <div class="edit-payment-modal" id="paymentModal">
        <div class="edit-payment-box">
            <h3>Edit Payment Status</h3>
            <label for="totalAmount">Total Amount:</label>
            <input type="text" id="totalAmount" readonly style="background:#f5f5f5">
            
            <label for="statusSelect">Payment Status:</label>
            <select id="statusSelect" style="width:100%;padding:8px;border:1px solid #ccc;border-radius:6px;margin-top:4px">
                <option value="0">Unpaid</option>
                <option value="1">Paid</option>
            </select>
            
            <div class="btn-group">
                <button class="btn-save" onclick="savePayment()">Save</button>
                <button class="btn-cancel" onclick="closePaymentModal()">Cancel</button>
            </div>
        </div>
    </div>

    <script>
    let currentBookingId = null;
    function openPaymentModal(bookingId, totalAmount, currentIsPaid) {
        currentBookingId = bookingId;
        const total = Math.round(parseFloat(totalAmount));
        document.getElementById('totalAmount').value = '₱' + total;
        const select = document.getElementById('statusSelect');
        select.value = (parseInt(currentIsPaid,10) === 1) ? '1' : '0';
        document.getElementById('paymentModal').classList.add('open');
        select.focus();
    }
    function closePaymentModal() {
        document.getElementById('paymentModal').classList.remove('open');
        currentBookingId = null;
    }
    function savePayment() {
        if (!currentBookingId) return;
        const isPaid = parseInt(document.getElementById('statusSelect').value, 10);
        const formData = new FormData();
        formData.append('action', 'update_paid');
        formData.append('booking_id', currentBookingId);
        formData.append('is_paid', isPaid);
        
        fetch(window.location.href, {method: 'POST', body: formData})
            .then(r => r.json())
            .then(d => {
                if (d.success) {
                    location.reload();
                } else {
                    alert('Failed to update payment status');
                }
            })
            .catch(e => {
                console.error(e);
                alert('Error updating payment');
            });
    }
    document.getElementById('paymentModal')?.addEventListener('click', function(e) {
        if (e.target === this) closePaymentModal();
    });
    </script>
