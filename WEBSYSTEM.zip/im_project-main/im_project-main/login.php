<?php
ob_start();
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Login page handler and form (post-login redirects handled after auth)

require_once 'classes/Auth.php';

$error = '';
$auth = new Auth();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    if ($auth->login($username, $password)) {
        // role-based redirect
        $role = $auth->getRole();
        if ($role === 'super_admin' || $role === 'admin' || $role === 'secretary') {
            header('Location: dashboard_admin.php');
        } else {
            header('Location: dashboard.php');
        }
        exit;
    } else {
        $error = 'Invalid username or password. Please try again.';
     }
 }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Booking System</title>
    <link rel="stylesheet" href="assets/css/styles.css">
    <style>
        :root{
            --primary:#1b3a0d;
            --accent:#2d5016;
            --bg:#cfd6d9;
            --card:#ffffff;
            --muted:#3d6b1f;
        }
        *{box-sizing:border-box;color:var(--primary);}
        body{margin:0;background:var(--bg);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial}
        .page-header{display:flex;align-items:center;justify-content:space-between;padding:16px 40px;background:var(--accent);color:#ffffff;border-bottom:2px solid rgba(0,0,0,0.06)}
        .header-left{width:120px}
        .header-center{flex:1;text-align:center;font-weight:700;color:#ffffff;letter-spacing:1px;font-size:1.3rem}
        .header-right{width:auto;display:flex;justify-content:flex-end;align-items:center;gap:16px;font-size:1rem}
        .header-btn{background:#ffffff;color:var(--accent);padding:10px 20px;border-radius:10px;text-decoration:none;font-weight:700;border:2px solid rgba(255,255,255,0.85)}
        .header-btn:hover{background:#f0f0f0;transform:scale(1.03)}

        .login-container { min-height: calc(100vh - 160px); display: flex; align-items: center; justify-content: center; padding: 24px; }
        .login-box { background: var(--card); padding: 48px; border-radius: 12px; border: 2px solid rgba(0,0,0,0.04); box-shadow: 0 12px 30px rgba(10,20,30,0.06); max-width: 700px; width: 100%; }
        .login-box h1 { text-align: center; color: var(--accent); margin-bottom: 16px; font-size: 2rem; }
        .form-group { margin-bottom: 16px; }
        .form-group label { display: block; font-weight: 700; color:var(--muted); margin-bottom: 8px; }
        .form-group input { width: 100%; padding: 12px 14px; border-radius: 8px; border:1px solid rgba(0,0,0,0.08); font-size:1rem; }
        .login-btn { width:100%; padding:12px 16px; background:var(--accent); color:#fff; border:none; border-radius:8px; font-weight:700; cursor:pointer; }
        .login-btn:hover{background:#1b3a0d}
        .error{background:#fdecea;padding:12px;border-radius:8px;color:#900;margin-bottom:12px}

        .site-footer { width:100%; box-sizing:border-box; background:var(--card); border-top:2px solid var(--accent); padding:18px 36px; display:flex; gap:20px; align-items:flex-start; justify-content:space-between; position:fixed; left:0; right:0; bottom:0; z-index:1000; }
        main { padding-bottom:140px; }
        .site-footer .footer-left img { height:70px; width:auto; display:block; }
        .site-footer .footer-left { display:flex; gap:12px; align-items:center; }
        .site-footer .contact { font-weight:700; color:var(--primary); margin-top:6px; }
        .site-footer .footer-links ul { margin:0; padding-left:0; color:var(--primary); display:grid; grid-template-columns: repeat(2, minmax(140px,1fr)); gap:8px 16px; list-style:none; }
        @media(max-width:760px){ .site-footer{flex-direction:column;align-items:flex-start} .site-footer .footer-links{margin-top:12px} }
    </style>
</head>
<body>
<header class="page-header" role="banner">
    <div class="header-left"></div>
    <div class="header-center">MARIGOLD SUBDIVISION COURT BOOKING</div>
    <div class="header-right">
        <a href="dashboard.php" class="header-btn">&larr; Dashboard</a>
    </div>
</header>

<div class="login-container">
    <div class="login-box">
        <h1>Login</h1>

        <?php if ($error): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required autofocus>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>

            <button type="submit" class="login-btn">Login</button>
        </form>
    </div>
</div>
    <!-- Footer: full-width site footer -->
    <footer class="site-footer" role="contentinfo">
         <div class="footer-left">
             <img src="assets/logo.png" alt="Marigold Logo">
             <div>
                 <div class="sub-name">Marigold Subdivision</div>
                 <div class="address">Phase 1 Marigold Subdivision Burgos, Rodriguez, Rizal.</div>
                 <div class="contact">Contact: <a href="tel:0962620781" style="color:var(--primary);text-decoration:none;">0962620781</a></div>
             </div>
         </div>
         <div class="footer-links" aria-label="Footer links">
             <!-- Footer links removed -->
         </div>
    </footer>
    </body>
    </html>