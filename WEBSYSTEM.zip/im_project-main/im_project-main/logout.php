<?php
ob_start();
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'classes/Auth.php';

$auth = new Auth();
$auth->logout();
header("Location: index.php");
exit;