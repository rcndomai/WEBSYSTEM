// ============================================================================
// MARIGOLD COURT BOOKING SYSTEM - HTML/JS Version (No Database)
// ============================================================================

// Storage keys
const STORAGE_KEYS = {
    USERS: 'marigold_users',
    BOOKINGS: 'marigold_bookings',
    CURRENT_USER: 'marigold_current_user',
    ACTIVITY_LOG: 'marigold_activity_log'
};

// Roles
const ROLES = {
    SUPER_ADMIN: 'super_admin',
    ADMIN: 'admin',
    SECRETARY: 'secretary',
    USER: 'user'
};

// ============================================================================
// AUTH SYSTEM
// ============================================================================

const AuthSystem = {
    // Initialize with default users
    init: function() {
        try {
            let existing = localStorage.getItem(STORAGE_KEYS.USERS);
            let validUsers = false;

            if (existing) {
                try {
                    const parsed = JSON.parse(existing);
                    validUsers = Array.isArray(parsed) && parsed.length > 0;

                } catch (err) {
                    validUsers = false;
                }
            }

            if (!validUsers) {
                const defaultUsers = [
                    { id: 1, username: 'admin', password: 'admin123', role: ROLES.ADMIN, email: 'admin@marigold.com' },
                    { id: 2, username: 'secretary', password: 'secretary123', role: ROLES.SECRETARY, email: 'sec@marigold.com' },
                    { id: 3, username: 'user', password: 'user123', role: ROLES.USER, email: 'user1@marigold.com' }
                ];
                localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(defaultUsers));
                console.log('Default users initialized');
            }

            if (!localStorage.getItem(STORAGE_KEYS.ACTIVITY_LOG)) {
                localStorage.setItem(STORAGE_KEYS.ACTIVITY_LOG, JSON.stringify([]));
            }
            if (!localStorage.getItem(STORAGE_KEYS.BOOKINGS)) {
                localStorage.setItem(STORAGE_KEYS.BOOKINGS, JSON.stringify([]));
            }
        } catch (e) {
            console.error('LocalStorage error:', e);
        }
    },

    login: function(username, password) {
        try {
            this.init();

            const usersJSON = localStorage.getItem(STORAGE_KEYS.USERS);
            if (!usersJSON) {
                return false;
            }

            const users = JSON.parse(usersJSON);
            const normalizedUsername = (username || '').trim().toLowerCase();
            const normalizedPassword = (password || '').trim();

            const user = users.find(function(u) {
                return u.username.toLowerCase() === normalizedUsername &&
                    u.password === normalizedPassword;
            });

            if (user) {
                const userData = {
                    id: user.id,
                    username: user.username,
                    role: user.role,
                    email: user.email
                };
                sessionStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(userData));
                return true;
            }

            return false;

        } catch (e) {
            console.error('Login error:', e);
            return false;
        }
    },

    logout: function() {
        sessionStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
    },

    getCurrentUser: function() {
        const user = sessionStorage.getItem(STORAGE_KEYS.CURRENT_USER);
        return user ? JSON.parse(user) : null;
    },

    isLoggedIn: function() {
        return !!this.getCurrentUser();
    },

    getRole: function() {
        const user = this.getCurrentUser();
        return user ? user.role : null;
    },

    hasRole: function(role) {
        return this.getRole() === role;
    },

    canManageBookings: function() {
        const role = this.getRole();
        return role === ROLES.ADMIN || role === ROLES.SECRETARY || role === ROLES.SUPER_ADMIN;
    },

    canManageUsers: function() {
        const role = this.getRole();
        return role === ROLES.ADMIN || role === ROLES.SUPER_ADMIN;
    },

    createUser: function(username, password, email, role) {
        const users = JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]');
        if (users.some(u => u.username === username)) {
            return { success: false, error: 'Username already exists' };
        }
        const newUser = {
            id: Math.max(...users.map(u => u.id), 0) + 1,
            username,
            password,
            email,
            role: role || ROLES.USER
        };
        users.push(newUser);
        localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
        return { success: true, user: newUser };
    }
};

// ============================================================================
// BOOKING SYSTEM
// ============================================================================

const BookingSystem = {
    init: function() {
        if (!localStorage.getItem(STORAGE_KEYS.BOOKINGS)) {
            localStorage.setItem(STORAGE_KEYS.BOOKINGS, JSON.stringify([]));
        }
    },

    createBooking: function(date, startTime, endTime, name, isPaid, reason, isHomeowner, electricity) {
        const bookings = JSON.parse(localStorage.getItem(STORAGE_KEYS.BOOKINGS) || '[]');
        
        // Check for conflicts
        const conflict = bookings.some(b => 
            b.date === date && 
            !(endTime <= b.startTime || startTime >= b.endTime)
        );
        
        if (conflict) {
            return { success: false, error: 'Time slot already booked' };
        }

        // Calculate pricing
        const startHour = parseInt(startTime.split(':')[0]);
        const endHour = parseInt(endTime.split(':')[0]);
        const hours = endHour - startHour;
        
        let hourlyRate = isHomeowner ? 200 : 400;
        const electricityFee = electricity ? 150 : 0;
        const totalPrice = (hours * hourlyRate) + electricityFee;

        const booking = {
            id: Math.max(...bookings.map(b => b.id || 0), 0) + 1,
            date,
            startTime,
            endTime,
            name,
            reason,
            isPaid: isPaid ? 1 : 0,
            isHomeowner: isHomeowner ? 1 : 0,
            electricity: electricity ? 1 : 0,
            totalPrice,
            createdAt: new Date().toISOString(),
            userId: AuthSystem.getCurrentUser().id
        };

        bookings.push(booking);
        localStorage.setItem(STORAGE_KEYS.BOOKINGS, JSON.stringify(bookings));

        // Log activity
        ActivityLog.add('CREATE', `Booking created for ${name} on ${date}`);

        return { success: true, booking };
    },

    getBookings: function(date = null) {
        let bookings = JSON.parse(localStorage.getItem(STORAGE_KEYS.BOOKINGS) || '[]');
        if (date) {
            bookings = bookings.filter(b => b.date === date);
        }
        return bookings.sort((a, b) => {
            if (a.date !== b.date) return new Date(a.date) - new Date(b.date);
            return a.startTime.localeCompare(b.startTime);
        });
    },

    deleteBooking: function(id) {
        let bookings = JSON.parse(localStorage.getItem(STORAGE_KEYS.BOOKINGS) || '[]');
        const booking = bookings.find(b => b.id === id);
        if (!booking) {
            return { success: false, error: 'Booking not found' };
        }
        bookings = bookings.filter(b => b.id !== id);
        localStorage.setItem(STORAGE_KEYS.BOOKINGS, JSON.stringify(bookings));
        ActivityLog.add('DELETE', `Booking deleted for ${booking.name} on ${booking.date}`);
        return { success: true };
    },

    deleteAllByDate: function(date) {
        let bookings = JSON.parse(localStorage.getItem(STORAGE_KEYS.BOOKINGS) || '[]');
        const before = bookings.length;
        bookings = bookings.filter(b => b.date !== date);
        const deleted = before - bookings.length;
        localStorage.setItem(STORAGE_KEYS.BOOKINGS, JSON.stringify(bookings));
        if (deleted > 0) {
            ActivityLog.add('DELETE_ALL', `Deleted ${deleted} bookings on ${date}`);
        }
        return deleted > 0;
    },

    updatePaidStatus: function(id, isPaid) {
        let bookings = JSON.parse(localStorage.getItem(STORAGE_KEYS.BOOKINGS) || '[]');
        const booking = bookings.find(b => b.id === id);
        if (!booking) return false;
        booking.isPaid = isPaid ? 1 : 0;
        localStorage.setItem(STORAGE_KEYS.BOOKINGS, JSON.stringify(bookings));
        ActivityLog.add('PAYMENT_UPDATE', `Payment status updated for booking ${id}`);
        return true;
    },

    timeToMinutes: function(timeStr) {
        const [hour, minute] = timeStr.split(':').map(Number);
        return (hour || 0) * 60 + (minute || 0);
    },

    getBookingsByMonth: function(month, year) {
        const bookings = this.getBookings();
        return bookings.filter(b => {
            const d = new Date(b.date);
            return d.getMonth() + 1 === month && d.getFullYear() === year;
        });
    }
};

// ============================================================================
// ACTIVITY LOG
// ============================================================================

const ActivityLog = {
    add: function(action, details) {
        const logs = JSON.parse(localStorage.getItem(STORAGE_KEYS.ACTIVITY_LOG) || '[]');
        const user = AuthSystem.getCurrentUser();
        logs.push({
            id: logs.length + 1,
            action,
            details,
            username: user ? user.username : 'system',
            createdAt: new Date().toISOString()
        });
        localStorage.setItem(STORAGE_KEYS.ACTIVITY_LOG, JSON.stringify(logs));
    },

    getAll: function() {
        return JSON.parse(localStorage.getItem(STORAGE_KEYS.ACTIVITY_LOG) || '[]').reverse();
    }
};

// ============================================================================
// CALENDAR UTILITIES
// ============================================================================

const CalendarUtils = {
    getDaysInMonth: function(month, year) {
        return new Date(year, month, 0).getDate();
    },

    getFirstDayOfMonth: function(month, year) {
        return new Date(year, month - 1, 1).getDay();
    },

    getDateStatus: function(date, bookings) {
        const dateBookings = bookings.filter(b => b.date === date);
        if (dateBookings.length === 0) return 'available';
        if (dateBookings.length < 2) return 'partial';
        return 'booked';
    },

    formatDate: function(date) {
        return new Date(date).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
    },

    getMonthYear: function(month, year) {
        return new Date(year, month - 1, 1).toLocaleDateString('en-US', {
            month: 'long',
            year: 'numeric'
        });
    }
};

// ============================================================================
// UI UTILITIES
// ============================================================================

const UIUtils = {
    redirectIfNotLoggedIn: function() {
        if (!AuthSystem.isLoggedIn()) {
            window.location.href = 'index.html';
        }
    },

    redirectIfWrongRole: function(roles) {
        const currentRole = AuthSystem.getRole();
        if (!roles.includes(currentRole)) {
            window.location.href = 'index.html';
        }
    },

    showModal: function(title, message) {
        alert(`${title}: ${message}`);
    },

    showError: function(element, message) {
        if (element) {
            const errorDiv = document.createElement('div');
            errorDiv.className = 'error';
            errorDiv.textContent = message;
            element.innerHTML = '';
            element.appendChild(errorDiv);
        } else {
            alert('Error: ' + message);
        }
    },

    formatTime: function(timeStr) {
        return timeStr; // Already in HH:MM format
    },

    formatPrice: function(price) {
        return '₱' + parseFloat(price).toFixed(2);
    }
};

// ============================================================================
// INITIALIZE ON PAGE LOAD
// ============================================================================

document.addEventListener('DOMContentLoaded', function() {
    AuthSystem.init();
    BookingSystem.init();
});
