<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once 'classes/Auth.php';
require_once 'classes/Role.php';

$auth = new Auth();
// Permission: manage users
$roleObj = new Role($auth->getRole());
if (!$auth->isLoggedIn() || !$roleObj->canManageUsers()) {
    header('Location: login.php');
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? '';

    if ($username === '' || $password === '' || $role === '') {
        $error = 'Please provide username, password and role.';
    } elseif (!in_array($role, Role::getAssignableRoles())) {
        $error = 'Invalid role selected.';
    } else {
        // DB connect
        $db = new mysqli('localhost','root','', 'marigold_court');
        if ($db->connect_error) {
            $error = 'Database connection failed: ' . $db->connect_error;
        } else {
            // Username check
            $stmt = $db->prepare('SELECT id FROM users WHERE username = ? LIMIT 1');
            if (!$stmt) {
                $error = 'DB prepare failed: ' . $db->error;
            } else {
                $stmt->bind_param('s', $username);
                $stmt->execute();
                $res = $stmt->get_result();
                if ($res && $res->num_rows > 0) {
                    $error = 'Username already exists.';
                    $stmt->close();
                } else {
                    $stmt->close();
                    $hash = password_hash($password, PASSWORD_DEFAULT);
                    $ins = $db->prepare('INSERT INTO users (username, password_hash, role, is_active, created_at, updated_at) VALUES (?, ?, ?, 1, NOW(), NOW())');
                    if (!$ins) {
                        $error = 'DB insert prepare failed: ' . $db->error;
                    } else {
                        $ins->bind_param('sss', $username, $hash, $role);
                        if ($ins->execute()) {
                            $success = 'User created successfully.';
                        } else {
                            $error = 'Failed to create user: ' . $ins->error;
                        }
                        $ins->close();
                    }
                }
            }
            $db->close();
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Create Staff Account - Marigold</title>
    <link rel="stylesheet" href="assets/css/styles.css">
    <style>
        html, body { height: 100%; }
        body{font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial; margin:0; background:#cfd6d9; min-height:100vh; display:flex; flex-direction:column}
        .page-header{display:flex;align-items:center;justify-content:space-between;padding:22px 24px;background:#2d5016;color:#fff}
        .header-left{width:160px}
        .header-center{flex:1;text-align:center;font-weight:700;color:#fff;letter-spacing:1px;font-size:1.1rem}
        .header-right{width:160px;display:flex;justify-content:flex-end;gap:12px}
        .header-btn { background:#fff;color:#2d5016;padding:8px 12px;border-radius:10px;text-decoration:none;font-weight:700;border:2px solid rgba(0,0,0,0.06); display:inline-flex;align-items:center;gap:8px }
        .header-btn:hover { background:#f6f6f6; }
        .header-right .header-btn:first-child { min-width:150px; justify-content:center; padding-left:14px; padding-right:14px }

        /* Layout */
        .page-body { flex:1; display:flex; align-items:center; justify-content:center; padding:12px; box-sizing:border-box }
        /* Container */
        .container{max-width:700px; width:100%; margin:0 auto; padding:40px; background:#fff; border-radius:12px; border:2px solid rgba(0,0,0,0.04); box-shadow:0 12px 30px rgba(10,20,30,0.06);}
        h2 { text-align:center; color:#2d5016; margin-top:0; font-size:1.8rem; margin-bottom:12px }
        .form-group { margin-bottom:16px }
        .form-group label { display:block; font-weight:700; color:#2d5016; margin-bottom:8px }
        .form-group input, .form-group select { width:100%; padding:12px 14px; border-radius:8px; border:1px solid rgba(0,0,0,0.08); font-size:1rem }
        /* Inputs */
        #usernameField, #passwordField, #roleField { max-width:620px; }
        .btn-group{display:flex;gap:12px;margin-top:18px;align-items:flex-start}
        .btn-save{background:#2d5016;color:#fff;padding:12px 16px;border:none;border-radius:8px;font-weight:700;cursor:pointer;flex:1}
        .btn-cancel{background:#fff;padding:12px 16px;border-radius:8px;border:2px solid rgba(0,0,0,0.06);cursor:pointer;color:#2d5016;font-weight:700;text-decoration:none;display:inline-flex;align-items:center;justify-content:center;flex:1;margin-top:8px}
        .message{padding:12px;border-radius:8px;margin-top:12px}
        .error{background:#fdecea;color:#b71c1c}
        .success{background:#e9f7ee;color:#0b5f2b}
        main { padding-bottom: 20px; }
        @media (max-width:760px){ .container{margin:12px;padding:18px} .header-right{width:auto} }
    </style>
    <style>
        /* Footer in-flow */
        .site-footer { position: static !important; bottom: auto !important; left: auto !important; right: auto !important; width: 100% !important; }
        body { min-height: 100vh; }
        main { padding-bottom: 20px; }
    </style>
    <header class="page-header">
        <div class="header-left"></div>
        <div class="header-center">MARIGOLD SUBDIVISION COURT BOOKING</div>
        <div class="header-right">
            <a href="dashboard_admin.php" class="header-btn">&larr; Dashboard</a>
        </div>
    </header>
    <main class="page-body">
        <div class="container">
        <h2>Create Staff / Admin Account</h2>
        <?php if ($error): ?><div class="message error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
        <?php if ($success): ?><div class="message success"><?php echo htmlspecialchars($success); ?></div><?php endif; ?>
        <form method="post" id="createUserForm">
            <div class="form-group">
                <label for="usernameField">Username</label>
                <input name="username" type="text" required id="usernameField">
            </div>

            <div class="form-group">
                <label for="passwordField">Password</label>
                <input name="password" type="password" required id="passwordField">
            </div>

            <div class="form-group">
                <label for="roleField">Role</label>
                <select name="role" required id="roleField">
                    <option value="">Select role</option>
                    <option value="secretary">Secretary (staff)</option>
                    <option value="admin">Admin (superadmin)</option>
                </select>
            </div>

            <div class="btn-group">
                <button type="submit" class="btn-save">Create Account</button>
                <a href="dashboard_admin.php" class="btn-cancel">Cancel</a>
            </div>
        </form>

        <!-- Confirmation modal -->
        <div id="confirmModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.6);align-items:center;justify-content:center;z-index:9999"> 
            <div style="background:#fff;padding:20px;border-radius:10px;max-width:480px;margin:0 auto;box-shadow:0 12px 40px rgba(0,0,0,0.25)">
                <h3 style="margin-top:0;color:#2d5016">Confirm Create Account</h3>
                <div style="margin-top:8px;color:#333">Create account for <strong id="confirmUser"></strong> with role <strong id="confirmRole"></strong>?</div>
                <div style="margin-top:12px;display:flex;gap:8px;justify-content:flex-end">
                    <button id="confirmCancel" style="background:#ddd;padding:8px 12px;border-radius:6px;border:none;cursor:pointer">Cancel</button>
                    <button id="confirmOk" style="background:#2d5016;color:#fff;padding:8px 12px;border-radius:6px;border:none;cursor:pointer">Confirm</button>
                </div>
            </div>
        </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="site-footer" role="contentinfo">
        <div class="footer-left">
            <img src="assets/logo.png" alt="Marigold Logo">
            <div>
                <div class="sub-name">Marigold Subdivision</div>
                <div class="address">Phase 1 Marigold Subdivision Burgos, Rodriguez, Rizal.</div>
                <div class="contact">Contact: <a href="tel:0962620781" style="color:var(--primary-color);text-decoration:none;">0962620781</a></div>
            </div>
        </div>
        <div class="footer-links" aria-label="Footer links">
            <!-- footer links -->
        </div>
    </footer>

    <script>
        (function(){
            const form = document.getElementById('createUserForm');
            const modal = document.getElementById('confirmModal');
            const confirmUser = document.getElementById('confirmUser');
            const confirmRole = document.getElementById('confirmRole');
            const ok = document.getElementById('confirmOk');
            const cancel = document.getElementById('confirmCancel');

            form.addEventListener('submit', function(e){
                e.preventDefault();
                const username = document.getElementById('usernameField').value.trim();
                const role = document.getElementById('roleField').value;
                if (!username || !role) {
                    alert('Please fill username and role.');
                    return;
                }
                confirmUser.textContent = username;
                confirmRole.textContent = role;
                modal.style.display = 'flex';
            });

            cancel.addEventListener('click', function(){ modal.style.display = 'none'; });
            ok.addEventListener('click', function(){ modal.style.display = 'none'; form.submit(); });

            // Close modal on click outside
            modal.addEventListener('click', function(e){ if (e.target === modal) modal.style.display = 'none'; });
        })();
    </script>
</body>
</html>
