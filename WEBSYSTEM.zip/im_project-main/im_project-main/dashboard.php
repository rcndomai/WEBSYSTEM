<?php

require_once "classes/Booking.php";
require_once "classes/BookingManager.php";

$manager = new BookingManager();
$bookings = $manager->getBookings();
$bookedDates = [];
if (!empty($bookings)) {
    foreach ($bookings as $b) {
        if (isset($b->date)) {
            $bookedDates[$b->date][] = $b;
        }
    }
}

// Header username (if logged in)
$headerUser = $_SESSION['username'] ?? $_SESSION['user_name'] ?? null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<title>Booking Calendar - Marigold</title>
	<link rel="stylesheet" href="assets/css/styles.css">
	<style>
		:root{
			--primary:#1b3a0d;
			--accent:#2d5016;
			--bg:#cfd6d9;
			--card:#ffffff;
			--muted:#3d6b1f;
		}
		*{box-sizing:border-box;color:var(--primary);}
		body{margin:0;background:var(--bg);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial;}
		/* Header */
		/* Header styles */
		.page-header{display:flex;align-items:center;justify-content:space-between;padding:16px 40px;background:var(--accent);color:#ffffff;border-bottom:2px solid rgba(0,0,0,0.06)}
		.header-left{width:120px}
		.header-center{flex:1;text-align:center;font-weight:700;color:#ffffff;letter-spacing:1px;font-size:1.3rem}
		.header-right{width:auto;display:flex;justify-content:flex-end;align-items:center;gap:16px;font-size:1rem}
		/* Header buttons */
		.header-btn{background:#ffffff;color:var(--accent);padding:10px 20px;border-radius:10px;text-decoration:none;font-weight:700;border:2px solid rgba(255,255,255,0.85)}
		.header-btn:hover{background:#f0f0f0;transform:scale(1.03)}
		/* Card */
		.calendar-main{display:flex;align-items:center;justify-content:center;padding:20px;overflow-x:hidden}
		.calendar-box{background:var(--card);max-width:1292px;width:100%;padding:46px;border-radius:12px;box-shadow:0 14px 34px rgba(10,20,30,0.08);margin:0 auto;transform:scale(0.95);transform-origin:top center}
		.calendar-box h1{margin:0 0 6px;text-align:center;color:var(--accent);font-size:2rem}
		.calendar-box h2{margin:0 0 18px;text-align:center;color:var(--muted);font-weight:600;font-size:1.2rem}
		/* Grid */
		.calendar{max-width:100%;margin:10px auto 0;overflow-x:hidden}
		.calendar-row{display:flex;gap:12px;margin-bottom:12px}
		.calendar-row.calendar-header{font-weight:700;color:var(--accent);font-size:.95rem}
		.calendar-row.calendar-header>div{flex:1;text-align:center}
		.calendar-cell{flex:1;min-height:133px;border-radius:12px;padding:11px;display:flex;flex-direction:column;align-items:flex-start;background:#fff;box-shadow:0 8px 22px rgba(10,20,30,0.06);transition:transform .12s;font-size:1.10rem;border:2px solid var(--muted)}
		.calendar-cell.empty{background:transparent;box-shadow:none;border:none}
		.calendar-cell:hover{transform:translateY(-4px)}
		.date-num{font-weight:700;color:var(--primary);margin-bottom:8px;font-size:1.6rem}
		.label{margin-top:auto;color:var(--accent);font-size:1.15rem;font-weight:600}
		/* States */
		.calendar-cell.available{background:#D4E8D4;border:2px solid #2d5016}
		.calendar-cell.partial{background:#FFE5B4;border:2px solid #D4A574}
		.calendar-cell.booked{background:#FFB8B8;border:2px solid #D96B6B}
		.calendar-cell.closed{background:#C9C9C9;border:2px solid #1b3a0d}
		/* Month display */
		.month-display{flex:1;text-align:center;font-weight:700;color:var(--primary);border:3px solid var(--accent);padding:12px 20px;border-radius:10px;background:#f0f8e8;min-width:200px}
		/* Nav pill */
		.calendar-nav{display:flex;align-items:center;justify-content:center;gap:12px;margin-bottom:16px}
		.calendar-nav-pill{background:var(--accent);color:#fff;border:none;border-radius:20px;padding:8px 14px;font-weight:700;cursor:pointer;box-shadow:0 8px 20px rgba(45,80,22,0.12);font-size:0.95rem;min-width:90px;text-align:center}
		.calendar-nav-pill:hover{background:#1b3a0d;transform:translateY(-2px)}
		/* Modal */
		.modal-overlay{position:fixed;inset:0;background:rgba(0,0,0,0.55);display:none;align-items:center;justify-content:center;padding:18px;z-index:9999}
		.modal-box{background:var(--card);padding:32px;border-radius:8px;max-width:600px;width:100%;box-shadow:0 10px 30px rgba(0,0,0,0.2)}
		.modal-header{font-weight:700;margin-bottom:10px;font-size:1.4rem;color:var(--accent)}
		.modal-body{color:var(--muted);margin-bottom:12px;font-size:1.1rem}
		.btn-close{background:var(--accent);color:#fff;padding:10px 16px;border:none;border-radius:6px;cursor:pointer;font-weight:700}
		.btn-close:hover{background:#1b3a0d}
		.btn-secondary{background:#e8f0e0;color:var(--primary);padding:10px 18px;border-radius:20px;text-decoration:none;font-weight:700;border:2px solid var(--accent);transition:all .2s}
		.btn-secondary:hover{background:var(--accent);color:#fff}
		/* Footer */
		.site-footer { width:100%; box-sizing:border-box; background:var(--card); border-top:2px solid var(--accent); padding:18px 36px; display:flex; gap:20px; align-items:flex-start; justify-content:space-between; position:fixed; left:0; right:0; bottom:0; z-index:1000; }
		/* Footer spacing */
		main { padding-bottom:140px; }
		.site-footer .footer-left img { height:90px; width:auto; display:block; }
		.site-footer .footer-left { display:flex; align-items:flex-start; gap:12px; }
		.site-footer .sub-name { font-weight:700; color:var(--primary); font-size:1.2rem; }
		.site-footer .address { color:var(--muted); font-size:1.05rem; margin-top:6px; }
		.site-footer .contact { margin-top:6px; font-weight:700; color:var(--primary); font-size:1.05rem; }
		.site-footer .footer-links { margin-left:auto; }
		.site-footer .footer-links ul { margin:0; padding-left:0; display:flex; gap:12px; list-style:none; justify-content:flex-end; flex-wrap:nowrap; }
		.site-footer .footer-links li { margin:0; white-space:nowrap; }
		.site-footer .footer-links a { color:#fff; text-decoration:none; display:inline-block; padding:14px 28px; background:var(--accent); border-radius:20px; font-weight:700; font-size:1.1rem; transition:all 0.2s; box-shadow:0 4px 12px rgba(45,80,22,0.12); }
		.site-footer .footer-links a:hover { background:var(--primary); transform:translateY(-2px); box-shadow:0 6px 16px rgba(45,80,22,0.18); }
		/* Layout modal */
		.layout-modal-overlay { position:fixed; inset:0; background:rgba(0,0,0,0.6); display:none; align-items:center; justify-content:center; z-index:9998; padding:20px; }
		.layout-modal-overlay.open { display:flex; }
		.layout-modal-box { background:var(--card); border-radius:12px; box-shadow:0 20px 60px rgba(0,0,0,0.3); max-width:1000px; width:100%; max-height:90vh; overflow:auto; position:relative; }
		.layout-modal-header { position:sticky; top:0; background:var(--accent); color:#fff; padding:16px 20px; display:flex; justify-content:space-between; align-items:center; border-radius:12px 12px 0 0; z-index:10; }
		.layout-modal-header h2 { margin:0; font-size:1.3rem; color:#fff; }
		.layout-modal-close { background:transparent; border:none; color:#fff; font-size:24px; cursor:pointer; font-weight:700; padding:0; width:32px; height:32px; display:flex; align-items:center; justify-content:center; }
		.layout-modal-close:hover { opacity:0.8; }
		.layout-modal-body { padding:20px; }
		.layout-modal-body img { width:100%; height:auto; border-radius:8px; }
		/* Directions modal */
		.directions-modal-overlay { position:fixed; inset:0; background:rgba(0,0,0,0.6); display:none; align-items:center; justify-content:center; z-index:10000; padding:20px; }
		.directions-modal-overlay.open { display:flex; }
		.directions-modal-box { background:var(--card); border-radius:12px; box-shadow:0 20px 60px rgba(0,0,0,0.3); max-width:900px; width:100%; max-height:90vh; overflow:auto; position:relative; }
		.directions-modal-header { position:sticky; top:0; background:var(--accent); color:#fff; padding:12px 16px; display:flex; justify-content:space-between; align-items:center; border-radius:12px 12px 0 0; z-index:10; }
		.directions-modal-header h2 { margin:0; font-size:1.1rem; color:#fff; }
		.directions-modal-close { background:transparent; border:none; color:#fff; font-size:24px; cursor:pointer; font-weight:700; padding:0; width:32px; height:32px; display:flex; align-items:center; justify-content:center; }
		.directions-modal-close:hover { opacity:0.9; }
		.directions-modal-body { padding:16px; display:flex; justify-content:center; }
		.directions-modal-body img { max-width:100%; height:auto; border-radius:6px; }
		/* Modal blur */
		main.modal-blur { filter:blur(4px); opacity:0.4; pointer-events:none; }
		@media(max-width:760px){ .site-footer{flex-direction:column;align-items:flex-start} .site-footer .footer-links{margin-top:12px} }
		@media (max-width:700px) {
			.calendar-cell { min-height: 90px; padding:8px; }
			.calendar-box { padding:20px; }
		}
	</style>
</head>
<body>
<header class="page-header" role="banner">
	<div class="header-left"></div>
	<div class="header-center">
		MARIGOLD SUBDIVISION COURT BOOKING
	</div>
	<div class="header-right">
		<?php if ($headerUser): ?>
			<span style="font-size:1rem;color:#ffffff;font-weight:600">Welcome, <strong><?php echo htmlspecialchars($headerUser); ?></strong></span>
			<a href="logout.php" class="header-btn">🚪 Logout</a>
		<?php else: ?>
			<a href="login.php" class="header-btn">🔑 Login</a>
		<?php endif; ?>
	</div>
</header>

<main class="calendar-main" role="main">
	<section class="calendar-box" aria-labelledby="calendarTitle">
		<h1 id="calendarTitle">BOOKING CALENDAR</h1>
		<h2>Available Dates & Booking Status</h2>

		<?php
		$today = new DateTime('now', new DateTimeZone('Asia/Manila'));
		$currentMonth = (int)$today->format('n');
		$currentYear = (int)$today->format('Y');
		$viewMonth = isset($_GET['month']) ? (int)$_GET['month'] : $currentMonth;
		$viewYear = isset($_GET['year']) ? (int)$_GET['year'] : $currentYear;
		$prevMonth = $viewMonth - 1; $prevYear = $viewYear;
		if ($prevMonth < 1) { $prevMonth = 12; $prevYear--; }
		$nextMonth = $viewMonth + 1; $nextYear = $viewYear;
		if ($nextMonth > 12) { $nextMonth = 1; $nextYear++; }

		$showPrev = ($viewMonth != $currentMonth || $viewYear != $currentYear);
		$showNext = ($viewMonth == $currentMonth && $viewYear == $currentYear);

		echo '<div class="calendar-nav">';
		if ($showPrev) {
			echo '<button class="calendar-nav-pill" onclick="location.href=\'' . $_SERVER['PHP_SELF'] . '?month=' . $prevMonth . '&year=' . $prevYear . '\'">&laquo; Prev</button>';
		}
		echo '<div class="month-display">' . date('F Y', mktime(0,0,0,$viewMonth,1,$viewYear)) . '</div>';
		if ($showNext) {
			echo '<button class="calendar-nav-pill" onclick="location.href=\'' . $_SERVER['PHP_SELF'] . '?month=' . $nextMonth . '&year=' . $nextYear . '\'">Next &raquo;</button>';
		}
		echo '</div>';
		?>

		<div class="calendar" role="grid" aria-label="Booking calendar">
			<?php
			function renderCalendar($month, $year, $bookedDates) {
				$first = mktime(0,0,0,$month,1,$year);
				$daysInMonth = date('t',$first);
				$startDow = date('w',$first);
				$weeks = [];
				$week = array_fill(0,7,null);
				$day = 1;
				for ($i = $startDow; $i < 7; $i++) { $week[$i] = $day++; }
				$weeks[] = $week;
				while ($day <= $daysInMonth) {
					$week = array_fill(0,7,null);
					for ($i=0;$i<7 && $day <= $daysInMonth;$i++) $week[$i] = $day++;
					$weeks[] = $week;
				}
				echo '<div class="calendar-row calendar-header"><div>Sun</div><div>Mon</div><div>Tue</div><div>Wed</div><div>Thu</div><div>Fri</div><div>Sat</div></div>';
				$now = new DateTime('now', new DateTimeZone('Asia/Manila'));
				$todayStr = $now->format('Y-m-d');
				foreach ($weeks as $week) {
					echo '<div class="calendar-row">';
					foreach ($week as $i => $d) {
						if ($d === null) { echo '<div class="calendar-cell empty"></div>'; continue; }
						$dateStr = sprintf('%04d-%02d-%02d',$year,$month,$d);
						$isSunday = $i==0;
						$isPast = $dateStr < $todayStr;
						$bookingsForDay = $bookedDates[$dateStr] ?? [];
						$bookedMinutes = 0;
						if (!empty($bookingsForDay)) {
							foreach ($bookingsForDay as $b) {
								$s = strtotime($dateStr.' '.$b->startTime);
								$e = strtotime($dateStr.' '.$b->endTime);
								$bookedMinutes += max(0,($e-$s)/60);
							}
						}
						$cellClass = $isPast ? 'past' : ($isSunday ? 'closed' :  ( ($bookedMinutes >= ((22 - 8) * 60)) ? 'booked' : ($bookedMinutes>0 ? 'partial' : 'available') ));
						$label = $isPast ? 'Past' : ($cellClass === 'booked' ? 'Booked' : ($cellClass==='partial' ? 'Partially Booked' : ($cellClass==='closed' ? 'Closed' : 'Available')));
						// Make any non-past, non-Sunday cell clickable to show booked/available times
						$clickable = (!$isPast && !$isSunday) ? ' onclick="showBookedTimes(\''. $dateStr .'\')" style="cursor:pointer;"' : '';
						echo '<div class="calendar-cell ' . $cellClass . '"' . $clickable . '>';
						echo '<div class="date-num">' . $d . '</div>';
						echo '<div class="label">' . $label . '</div>';
						echo '</div>';
					}
					echo '</div>';
				}
			}
			renderCalendar($viewMonth,$viewYear,$bookedDates);
			?>
		</div>

		<div class="calendar-actions">
			<!-- pricing -->
		</div>
	</section>
</main>
 
		 <!-- full-width site footer -->
 <footer class="site-footer" role="contentinfo">
      <div class="footer-left">
          <img src="assets/logo.png" alt="Marigold Logo">
          <div>
              <div class="sub-name">Marigold Subdivision</div>
              <div class="address">Phase 1 Marigold Subdivision Burgos, Rodriguez, Rizal.</div>
              <div class="contact">Contact: <a href="tel:0962620781" style="color:var(--primary);text-decoration:none;">0962620781</a></div>
          </div>
      </div>
     <div class="footer-links" aria-label="Footer links">
        <ul>
            <li><a href="#" onclick="openDirectionsModal(event)">Directions</a></li>
            <li><a href="#" onclick="openLayoutModal(event)">Layout</a></li>
            <li><a href="#" onclick="openPicturesModal(event)">Pictures</a></li>
        </ul>
    </div>
 </footer>
 
 <!-- Directions modal -->
 <div class="directions-modal-overlay" id="directionsModal" aria-hidden="true" role="dialog" aria-modal="true">
 	<div class="directions-modal-box">
 		<div class="directions-modal-header">
 			<h2>Directions to the Court</h2>
 			<button class="directions-modal-close" onclick="closeDirectionsModal()" aria-label="Close">&times;</button>
 		</div>
 		<div class="directions-modal-body">
 			<img src="assets/directions.png" alt="Directions to Court">
 		</div>
 	</div>
 </div>
 
 <!-- Layout modal -->
 <div class="layout-modal-overlay" id="layoutModal">
 	<div class="layout-modal-box">
 		<div class="layout-modal-header">
 			<h2>Layout of the Court</h2>
 			<button class="layout-modal-close" onclick="closeLayoutModal()">&times;</button>
 		</div>
 		<div class="layout-modal-body">
 			<img src="assets/layout_court.jpg" alt="Court Layout">
 		</div>
 	</div>
 </div>
 
	<!-- Pictures Gallery Modal -->
	<div class="modal-overlay" id="picturesModal" aria-hidden="true" role="dialog" style="display:none;z-index:10001;background:rgba(0,0,0,0.75);">
		<div class="modal-box" style="max-width:95vw;position:relative;padding:12px;background:transparent;" role="document">
			<button class="btn-close" style="position:absolute;top:12px;right:12px;z-index:10;" onclick="closePicturesModal()" aria-label="Close">&times;</button>
			<div style="display:flex;align-items:center;justify-content:center;gap:20px;">
				<button class="calendar-nav-pill" style="background:rgba(255,255,255,0.9);color:var(--accent);font-size:32px;width:60px;height:60px;padding:0;" onclick="prevPicture()" aria-label="Previous">&lsaquo;</button>
				<img id="picturesModalImg" src="" alt="Court picture" style="max-width:90%;max-height:75vh;border-radius:8px;" />
				<button class="calendar-nav-pill" style="background:rgba(255,255,255,0.9);color:var(--accent);font-size:32px;width:60px;height:60px;padding:0;" onclick="nextPicture()" aria-label="Next">&rsaquo;</button>
			</div>
			<div id="picturesCaption" style="text-align:center;color:#fff;margin-top:12px;font-weight:700;font-size:1.1rem;"></div>
			<div style="display:flex;justify-content:center;gap:10px;margin-top:16px;flex-wrap:wrap;" id="pictureThumbnails"></div>
		</div>
	</div>

	<!-- Booked / Available times modal -->
	<div class="modal-overlay" id="bookedTimesModal" aria-hidden="true" role="dialog" aria-modal="true" style="display:none;">
		<div class="modal-box" role="document">
			<div class="modal-header">Times for <span id="modalDate"></span></div>
			<div class="modal-body" style="text-align:left;">
				<div>
					<strong>Booked Slots</strong>
					<ul id="bookedTimesList" style="margin-top:8px;padding-left:18px;color:#444;"></ul>
				</div>
				<div style="margin-top:12px;">
					<strong>Available Slots</strong>
					<ul id="availableTimesList" style="margin-top:8px;padding-left:18px;color:#0b6b5a;"></ul>
				</div>
			</div>
			<div style="display:flex;justify-content:flex-end;gap:8px;margin-top:12px;">
				<button id="modalCloseBtn" class="btn-close">Close</button>
			</div>
		</div>
	</div>

 <script>
 	const bookedDatesData = <?php echo json_encode($bookedDates); ?>;
	// Pictures gallery
	const pictures = ['assets/court1.jpg','assets/court2.jpg','assets/court_center.jpg','assets/clubhouse.jpg','assets/court_clubhouse_side.jpg','assets/court_otherside.jpg','assets/bathroom.jpg'];
	let currentPicIndex = 0;
	function openPicturesModal(e){
		e && e.preventDefault();
		const modal = document.getElementById('picturesModal');
		const img = document.getElementById('picturesModalImg');
		const cap = document.getElementById('picturesCaption');
		if (!modal || !img) return;
		currentPicIndex = 0;
		img.src = pictures[currentPicIndex];
		cap.textContent = (currentPicIndex+1) + ' / ' + pictures.length;
		generateThumbnails();
		modal.style.display = 'flex';
		modal.setAttribute('aria-hidden','false');
		document.querySelector('main')?.classList.add('modal-blur');
	}
	function closePicturesModal(){
		const modal = document.getElementById('picturesModal');
		if (!modal) return;
		modal.style.display = 'none';
		modal.setAttribute('aria-hidden','true');
		document.querySelector('main')?.classList.remove('modal-blur');
	}
	function nextPicture(){
		currentPicIndex = (currentPicIndex + 1) % pictures.length;
		updatePicture();
	}
	function prevPicture(){
		currentPicIndex = (currentPicIndex - 1 + pictures.length) % pictures.length;
		updatePicture();
	}
	function updatePicture(){
		const img = document.getElementById('picturesModalImg');
		const cap = document.getElementById('picturesCaption');
		if (img) img.src = pictures[currentPicIndex];
		if (cap) cap.textContent = (currentPicIndex+1) + ' / ' + pictures.length;
		updateThumbnailActive();
	}
	function generateThumbnails(){
		const container = document.getElementById('pictureThumbnails');
		if (!container) return;
		container.innerHTML = '';
		pictures.forEach((pic, idx) => {
			const thumb = document.createElement('img');
			thumb.src = pic;
			thumb.style.cssText = 'width:70px;height:70px;object-fit:cover;border-radius:6px;cursor:pointer;border:3px solid transparent;transition:all 0.2s;';
			if (idx === currentPicIndex) thumb.style.borderColor = '#2d5016';
			thumb.onclick = () => { currentPicIndex = idx; updatePicture(); };
			container.appendChild(thumb);
		});
	}
	function updateThumbnailActive(){
		const thumbs = document.getElementById('pictureThumbnails')?.querySelectorAll('img');
		if (thumbs) thumbs.forEach((t, i) => { t.style.borderColor = i === currentPicIndex ? '#2d5016' : 'transparent'; });
	}
	document.getElementById('picturesModal')?.addEventListener('click', function(e){ if (e.target.id === 'picturesModal') closePicturesModal(); });
	/* Directions modal open/close (overlay with blur) */
	function openDirectionsModal(e) {
		e && e.preventDefault();
		const modal = document.getElementById('directionsModal');
		const main = document.querySelector('main');
		if (!modal) return;
		modal.classList.add('open');
		modal.setAttribute('aria-hidden','false');
		if (main) main.classList.add('modal-blur');
	}
	function closeDirectionsModal() {
		const modal = document.getElementById('directionsModal');
		const main = document.querySelector('main');
		if (!modal) return;
		modal.classList.remove('open');
		modal.setAttribute('aria-hidden','true');
		if (main) main.classList.remove('modal-blur');
	}
 	function openLayoutModal(e) {
 		e.preventDefault();
 		const modal = document.getElementById('layoutModal');
 		const main = document.querySelector('main');
 		if (modal) {
 			modal.classList.add('open');
 			if (main) main.classList.add('modal-blur');
 		}
 	}
 	function closeLayoutModal() {
 		const modal = document.getElementById('layoutModal');
 		const main = document.querySelector('main');
 		if (modal) {
 			modal.classList.remove('open');
 			if (main) main.classList.remove('modal-blur');
 		}
 	}
 	// Close modal on background click
 	document.getElementById('layoutModal')?.addEventListener('click', function(e) {
 		if (e.target === this) closeLayoutModal();
 	});

	// Close directions modal on background click
	document.getElementById('directionsModal')?.addEventListener('click', function(e) {
		if (e.target === this) closeDirectionsModal();
	});
 
	function showBookedTimes(dateStr){
		const modal = document.getElementById('bookedTimesModal');
		const dateEl = document.getElementById('modalDate');
		const bookedList = document.getElementById('bookedTimesList');
		const availList = document.getElementById('availableTimesList');
		if (!modal || !dateEl || !bookedList || !availList) return;
		dateEl.textContent = dateStr;
		bookedList.innerHTML = '';
		availList.innerHTML = '';
		const bookings = bookedDatesData[dateStr] || [];

		function toMinutes(t){ const p = (t||'00:00').split(':').map(Number); return p[0]*60 + p[1]; }
		function fmtMinutes(m){ const hh = Math.floor(m/60); return (hh<10? '0':'')+hh+':00'; }

		// determine start hour (weekend earlier start)
		const dt = new Date(dateStr + 'T00:00:00');
		const dow = dt.getDay(); // 0=Sun,6=Sat
		const startHour = (dow === 6) ? 5 : 8; // Saturday starts 05:00, weekdays 08:00
		const endHour = 22; // close at 22:00

		// build hourly slots with booked flag
		const slots = [];
		for (let h = startHour; h < endHour; h++) {
			const s = h*60;
			const e = (h+1)*60;
			const isBooked = bookings.some(b => !(e <= toMinutes(b.startTime) || s >= toMinutes(b.endTime)));
			slots.push({ s, e, booked: !!isBooked });
		}

		function compressRanges(items, wantedBooked){
			const ranges = [];
			let cur = null;
			items.forEach(slot => {
				if (slot.booked === wantedBooked) {
					if (!cur) cur = { s: slot.s, e: slot.e };
					else cur.e = slot.e;
				} else {
					if (cur) { ranges.push(cur); cur = null; }
				}
			});
			if (cur) ranges.push(cur);
			return ranges;
		}

		const bookedRanges = compressRanges(slots, true);
		const availRanges = compressRanges(slots, false);

		if (bookedRanges.length === 0) {
			const li = document.createElement('li'); li.textContent = 'No booked slots'; li.style.color='#666'; bookedList.appendChild(li);
		} else {
			bookedRanges.forEach(r => { const li = document.createElement('li'); li.textContent = fmtMinutes(r.s) + ' - ' + fmtMinutes(r.e); bookedList.appendChild(li); });
		}
		if (availRanges.length === 0) {
			const li = document.createElement('li'); li.textContent = 'No available slots'; li.style.color='#666'; availList.appendChild(li);
		} else {
			availRanges.forEach(r => { const li = document.createElement('li'); li.textContent = fmtMinutes(r.s) + ' - ' + fmtMinutes(r.e); availList.appendChild(li); });
		}

		modal.style.display = 'flex';
		modal.setAttribute('aria-hidden','false');
	}

	(function(){
		const modal = document.getElementById('bookedTimesModal');
		const closeBtn = document.getElementById('modalCloseBtn');
		if (!modal) return;
		closeBtn && closeBtn.addEventListener('click', () => { modal.style.display='none'; modal.setAttribute('aria-hidden','true'); });
		modal.addEventListener('click', function(e){ if (e.target === modal) { modal.style.display='none'; modal.setAttribute('aria-hidden','true'); } });
	})();
 </script>
</body>
</html>