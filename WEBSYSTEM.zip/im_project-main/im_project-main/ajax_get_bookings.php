<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once 'classes/Auth.php';
require_once 'classes/Role.php';
require_once 'classes/BookingManager.php';

$auth = new Auth();
if (!$auth->isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['error' => 'Not authenticated']);
    exit;
}
$role = new Role($auth->getRole());
if (!$role->canManageBookings()) {
    http_response_code(403);
    echo json_encode(['error' => 'Forbidden']);
    exit;
}

$date = $_GET['date'] ?? null;
if (!$date) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing date']);
    exit;
}

$mgr = new BookingManager();
$all = $mgr->getBookings();
$out = [];
foreach ($all as $b) {
    if ($b->date === $date) {
        $out[] = [
            'id' => $b->id ?? null,
            'date' => $b->date,
            'startTime' => $b->startTime,
            'endTime' => $b->endTime,
            'name' => $b->name,
            'isHomeowner' => $b->isHomeowner ?? 0,
            'electricity' => $b->electricity ?? 0,
            'isPaid' => $b->isPaid ?? 0,
        ];
    }
}

header('Content-Type: application/json');
echo json_encode(['bookings' => $out]);
exit;

?>
