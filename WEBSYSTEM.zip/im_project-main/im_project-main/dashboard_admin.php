<?php
ob_start();
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'classes/Auth.php';
require_once 'classes/Booking.php';
require_once 'classes/BookingManager.php';
$auth = new Auth();
require_once 'classes/Role.php';
// Access control: admin/secretary/super_admin only
$roleObj = new Role($auth->getRole());
if (!$auth->isLoggedIn() || !($roleObj->canManageBookings() || $roleObj->isUser())) {
    header('Location: login.php');
    exit;
}
 $manager = new BookingManager();

// Fetch bookings
$bookings = $manager->getBookings();
$bookedDates = [];
if (!empty($bookings)) {
    foreach ($bookings as $b) {
        if (isset($b->date)) {
            $bookedDates[$b->date][] = $b;
        }
    }
}

// Enable error reporting (diagnostic)
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Marigold Subdivision Court Booking</title>
    <link rel="stylesheet" href="assets/css/styles.css">
    <style>
        :root {
            --primary-color: #1b3a0d;
            --secondary-color: #2d5016;
            --background-gray: #cfd6d9;
            --light-bg: #ffffff;
            --text-color: #1b3a0d;
            --error-color: #e74c3c;
        }
        * { box-sizing: border-box; }
        html, body { height: 100%; }
        body { background: var(--background-gray); margin: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial; color:var(--text-color); height:100vh; overflow:hidden; }

        /* Header - match dashboard */
        .page-header { display:flex; align-items:center; justify-content:space-between; padding:16px 40px; background:var(--secondary-color); color:#fff; border-bottom:2px solid rgba(0,0,0,0.06); position:relative; }
        .header-left { width:120px; }
        .header-logo { position:absolute; left:50%; top:50%; transform:translate(-50%,-50%); font-size:1.6rem; font-weight:700; color:#fff; }
        .header-right { display:flex; gap:16px; align-items:center; }
        .header-link { background:#fff; color:var(--secondary-color); padding:8px 14px; border-radius:8px; text-decoration:none; font-weight:700; border:2px solid rgba(255,255,255,0.85); }
        .header-link:hover { background:#f0f0f0; }

        /* Content & calendar styles */
        .calendar-page-container { height: calc(100vh - 112px); display:flex; flex-direction:column; background: var(--background-gray); }
        /* Keep header+container+footer visible; allow internal scroll */
        .calendar-main { flex:1 1 auto; display:flex; align-items:center; justify-content:center; padding:15px; overflow:auto; max-height:100%; }
        .calendar-box { background: var(--light-bg); padding:46px; border-radius:12px; box-shadow:0 12px 30px rgba(0,0,0,0.12); max-width:1292px; width:100%; transform:scale(0.95); transform-origin:top center; }
        .calendar-box h1 { text-align: center; margin:0 0 6px 0; color: var(--secondary-color); font-size: 1.8rem; }
        .calendar-box h2 { text-align: center; margin:0 0 12px 0; color: var(--secondary-color); font-weight:600; font-size:1rem; }

        /* Calendar cell backgrounds */
        .calendar-cell.available { background: #D4E8D4; border: 2px solid #2d5016; color: var(--primary-color); font-weight: 600; }
        .calendar-cell.partial { background: #FFE5B4; border: 2px solid #D4A574; color: var(--primary-color); font-weight: 600; }
        .calendar-cell.booked { background: #FFB8B8; border: 2px solid #D96B6B; color: var(--primary-color); font-weight: 600; }
        .calendar-cell.closed { background: #C9C9C9; border: 2px solid #1b3a0d; color: var(--primary-color); font-weight: 600; }
        .calendar-cell.past { background: #A9A9A9; border: 2px solid #1b3a0d; color: var(--primary-color); font-weight: 600; }    

        /* Calendar grid styles */
        .calendar { max-width: 100%; margin: 0 auto; overflow-x: hidden; }
        .calendar-row { display: flex; gap: 12px; margin-bottom: 12px; }
        .calendar-row.calendar-header { font-weight: 700; color: var(--secondary-color); font-size: 0.85rem; }
        .calendar-row.calendar-header > div { flex: 1; text-align: center; }
        .calendar-cell { flex: 1; min-height: 133px; border-radius: 8px; padding: 11px; display:flex; flex-direction:column; align-items:center; justify-content:flex-start; box-shadow: 0 1px 0 rgba(0,0,0,0.03) inset; border: 2px solid var(--secondary-color); font-size: 1.10rem; }
            .calendar-cell { flex: 1; min-height: 133px; border-radius: 8px; padding: 11px; display:flex; flex-direction:column; align-items:center; justify-content:flex-start; box-shadow: 0 1px 0 rgba(0,0,0,0.03) inset; border: 2px solid var(--secondary-color); font-size: 1.25rem; }
        .calendar-cell.empty { background: transparent; box-shadow: none; border: none; }
            .date-num { font-size: 1.4rem; color: var(--primary-color); margin-bottom:6px; font-weight: 700; }
        .label { font-size: 0.8rem; color: var(--secondary-color); text-align: center; font-weight: 600; }
            .label { font-size: 0.95rem; color: var(--secondary-color); text-align: center; font-weight: 600; }
        .month-display { flex: 1; text-align: center; font-weight: 700; color: var(--primary-color); border: 3px solid var(--secondary-color); padding: 10px 18px; border-radius: 10px; background: #f0f8e8; min-width: 190px; font-size: 1.15rem; }
            .month-display { flex: 1; text-align: center; font-weight: 700; color: var(--primary-color); border: 3px solid var(--secondary-color); padding: 12px 20px; border-radius: 10px; background: #f0f8e8; min-width: 190px; font-size: 1.3rem; }
        .calendar-nav { display: flex; align-items: center; justify-content: center; gap: 12px; margin-bottom: 12px; }
        .calendar-nav-pill { background: var(--secondary-color); color: #fff; border: none; border-radius: 20px; padding: 6px 12px; font-weight: 700; cursor: pointer; box-shadow: 0 4px 12px rgba(45,80,22,0.12); font-size: 0.85rem; min-width: 80px; text-align: center; }
        .calendar-nav-pill:hover { background: var(--primary-color); transform: translateY(-2px); }

        @media (max-width:700px) {
            .calendar-row { gap:6px; }
            .calendar-cell { min-height:90px; padding:8px; }
            .calendar-box { padding:20px; }
        }
        .btn-primary-pill { background: var(--secondary-color); color: #fff; padding: 8px 16px; border-radius: 20px; text-decoration: none; font-weight: 600; font-size:0.9rem; }
        .btn-primary-pill:hover { background: var(--primary-color); }
        .btn-secondary { background: #e8f0e0; color: var(--primary-color); padding: 10px 18px; border-radius: 20px; text-decoration: none; font-weight: 700; border: 2px solid var(--secondary-color); }
        .btn-secondary:hover { background: var(--secondary-color); color: #fff; }

        .site-footer { width:100%; box-sizing:border-box; background:var(--light-bg); border-top:2px solid var(--secondary-color); padding:16px 40px; position:fixed; left:0; right:0; bottom:0; z-index:1000; display:flex; justify-content:space-between; align-items:flex-start; gap:24px; }
        .site-footer .footer-left img { height:80px; width:auto; display:block; border-radius:8px; }
        .site-footer .footer-left { display:flex; gap:12px; align-items:flex-start; }
        .site-footer .sub-name { font-weight:700; color:var(--primary-color); font-size:1rem; }
        .site-footer .address { color:var(--text-color); font-size:0.9rem; margin-top:4px; }
        .site-footer .contact { margin-top:4px; font-weight:700; color:var(--primary-color); font-size:0.95rem; }
        .site-footer .footer-links { margin-left:12px; }
        .site-footer .footer-links ul { margin:0; padding-left:0; color:var(--primary-color); display:flex; flex-direction:column; gap:3px; }
        .site-footer .footer-links li { margin:0; font-weight:700; font-size:0.9rem; }
         main { padding-bottom:140px; } /* ensure content not hidden by fixed footer */
         @media(max-width:760px){ .site-footer{flex-direction:column;align-items:flex-start;padding:12px} main{padding-bottom:180px} }
        .layout-modal-overlay { position:fixed; inset:0; background:rgba(0,0,0,0.6); display:none; align-items:center; justify-content:center; z-index:9998; padding:20px; }
        .layout-modal-overlay.open { display:flex; }
        .layout-modal-box { background:var(--light-bg); border-radius:12px; box-shadow:0 20px 60px rgba(0,0,0,0.3); max-width:1000px; width:100%; max-height:90vh; overflow:auto; position:relative; }
        .layout-modal-header { position:sticky; top:0; background:var(--secondary-color); color:#fff; padding:16px 20px; display:flex; justify-content:space-between; align-items:center; border-radius:12px 12px 0 0; z-index:10; }
        .layout-modal-header h2 { margin:0; font-size:1.3rem; color:#fff; }
        .layout-modal-close { background:transparent; border:none; color:#fff; font-size:24px; cursor:pointer; font-weight:700; padding:0; width:32px; height:32px; display:flex; align-items:center; justify-content:center; }
        .layout-modal-close:hover { opacity:0.8; }
        .layout-modal-body { padding:20px; }
        .layout-modal-body img { width:100%; height:auto; border-radius:8px; }
        /* Directions modal */
        .directions-modal-overlay { position:fixed; inset:0; background:rgba(0,0,0,0.6); display:none; align-items:center; justify-content:center; z-index:10000; padding:20px; }
        .directions-modal-overlay.open { display:flex; }
        .directions-modal-box { background:var(--light-bg); border-radius:12px; box-shadow:0 20px 60px rgba(0,0,0,0.3); max-width:900px; width:100%; max-height:90vh; overflow:auto; position:relative; }
        .directions-modal-header { position:sticky; top:0; background:var(--secondary-color); color:#fff; padding:12px 16px; display:flex; justify-content:space-between; align-items:center; border-radius:12px 12px 0 0; z-index:10; }
        .directions-modal-header h2 { margin:0; font-size:1.1rem; color:#fff; }
        .directions-modal-close { background:transparent; border:none; color:#fff; font-size:24px; cursor:pointer; font-weight:700; padding:0; width:32px; height:32px; display:flex; align-items:center; justify-content:center; }
        .directions-modal-close:hover { opacity:0.9; }
        .directions-modal-body { padding:16px; display:flex; justify-content:center; }
        .directions-modal-body img { max-width:100%; height:auto; border-radius:6px; }
        /* Blur main content when modal open */
        .calendar-page-container.modal-blur { filter:blur(4px); opacity:0.4; pointer-events:none; }
         main { padding-bottom:160px; } /* ensure content not hidden by fixed footer */
         @media(max-width:760px){ .site-footer{flex-direction:column;align-items:flex-start} main{padding-bottom:220px} }
     </style>
    </head>
    <body class="no-court-bg">
  <div class="page-header">
      <div class="header-left"></div>
      <div class="header-logo">MARIGOLD SUBDIVISION COURT BOOKING</div>
      <div class="header-right">
          <span style="font-weight:600;color:#fff">Welcome, <strong><?php echo htmlspecialchars($auth->getUsername()); ?></strong></span>
          <?php if ($roleObj->canManageUsers()): ?>
              <a href="create_user.php" class="header-link">➕ Create Account</a>
          <?php endif; ?>
          <?php if ($roleObj->isSuperAdmin()): ?>
              <a href="activity_log.php" class="header-link">📋 Activity Log</a>
          <?php endif; ?>
          <a href="logout.php" class="header-link">🚪 Logout</a>
      </div>
  </div>
  
  <div class="calendar-page-container">
      <div class="calendar-main">
          <div class="calendar-box">
              <h1>WELCOME ADMIN</h1>
              <h2 style="text-align:center;">Booking Calendar</h2>
              <?php
                $today = new DateTime('now', new DateTimeZone('Asia/Manila'));
                $currentMonth = (int)$today->format('n');
                $currentYear = (int)$today->format('Y');
                $viewMonth = isset($_GET['month']) ? (int)$_GET['month'] : $currentMonth;
                $viewYear = isset($_GET['year']) ? (int)$_GET['year'] : $currentYear;
                $prevMonth = $viewMonth - 1;
                $prevYear = $viewYear;
                if ($prevMonth < 1) { $prevMonth = 12; $prevYear--; }
                $nextMonth = $viewMonth + 1;
                $nextYear = $viewYear;
                if ($nextMonth > 12) { $nextMonth = 1; $nextYear++; }

                $showPrev = ($viewMonth != $currentMonth || $viewYear != $currentYear);
                $showNext = ($viewMonth == $currentMonth && $viewYear == $currentYear);

                $calendarNav = '<div style="display:flex;align-items:center;justify-content:center;margin-bottom:8px;">';
                if ($showPrev) {
                    $calendarNav .= '<button class="calendar-nav-pill" onclick="window.location.href=\'' . $_SERVER['PHP_SELF'] . '?month=' . $prevMonth . '&year=' . $prevYear . '\'">&laquo; Prev</button>';
                }
                $calendarNav .= '<div class="month-display">' . date('F Y', mktime(0,0,0,$viewMonth,1,$viewYear)) . '</div>';
                if ($showNext) {
                    $calendarNav .= '<button class="calendar-nav-pill" onclick="window.location.href=\'' . $_SERVER['PHP_SELF'] . '?month=' . $nextMonth . '&year=' . $nextYear . '\'">Next &raquo;</button>';
                }
                $calendarNav .= '</div>';
                echo $calendarNav;
            ?>
            <div class="calendar">
                <?php
                function renderAdminCalendar($month, $year, $bookedDates) {
                    $firstDayOfMonth = mktime(0, 0, 0, $month, 1, $year);
                    $daysInMonth = date('t', $firstDayOfMonth);
                    $startDayOfWeek = date('w', $firstDayOfMonth);
                    $weeks = [];
                    $week = array_fill(0, 7, null);
                    $dayCounter = 1;
                    for ($i = $startDayOfWeek; $i < 7; $i++) {
                        $week[$i] = $dayCounter++;
                    }
                    $weeks[] = $week;
                    while ($dayCounter <= $daysInMonth) {
                        $week = array_fill(0, 7, null);
                        for ($i = 0; $i < 7 && $dayCounter <= $daysInMonth; $i++) {
                            $week[$i] = $dayCounter++;
                        }
                        $weeks[] = $week;
                    }
                    echo '<div class="calendar-row calendar-header">';
                    echo '<div>Sun</div><div>Mon</div><div>Tue</div><div>Wed</div><div>Thu</div><div>Fri</div><div>Sat</div>';
                    echo '</div>';
                    $now = new DateTime('now', new DateTimeZone('Asia/Manila'));
                    $todayStr = $now->format('Y-m-d');
                    foreach ($weeks as $week) {
                        echo '<div class="calendar-row">';
                        foreach ($week as $i => $day) {
                            if ($day === null) {
                                            echo '<div class="calendar-cell empty"></div>';
                                        } else {
                                $dateStr = sprintf('%04d-%02d-%02d', $year, $month, $day);
                                $isSunday = $i == 0;
                                $isPast = $dateStr < $todayStr;
                                $bookingsForDay = isset($bookedDates[$dateStr]) ? $bookedDates[$dateStr] : [];
                                $isFullyBooked = false;
                                $isPartiallyBooked = false;
                                $bookedMinutes = 0;
                                if (!empty($bookingsForDay)) {
                                    foreach ($bookingsForDay as $booking) {
                                        $start = strtotime($dateStr.' '.$booking->startTime);
                                        $end = strtotime($dateStr.' '.$booking->endTime);
                                        $bookedMinutes += ($end - $start) / 60;
                                    }
                                    if (!$isSunday) {
                                        $openTime = $i == 6 ? strtotime($dateStr.' 05:30') : strtotime($dateStr.' 08:00');
                                        $closeTime = strtotime($dateStr.' 22:00');
                                        $totalMinutes = ($closeTime - $openTime) / 60;
                                        $isFullyBooked = ($bookedMinutes >= $totalMinutes);
                                        $isPartiallyBooked = !$isFullyBooked && $bookedMinutes > 0;
                                    }
                                }
                                $cellClass = $isPast ? 'past' : ($isSunday ? 'closed' : ($isFullyBooked ? 'booked' : ($isPartiallyBooked ? 'partial' : 'available')));
                                $label = $isPast ? 'Past' : ($isFullyBooked ? 'Booked' : ($isPartiallyBooked ? 'Partially Booked' : ($isSunday ? 'Closed' : 'Available')));
                                // If fully booked, open the date modal for admins/secretaries; otherwise go to booking page
                                $cellAttrs = '';
                                if (!$isPast && !$isSunday) {
                                    if ($isFullyBooked || $isPartiallyBooked) {
                                        $cellAttrs = ' style="cursor:pointer;" onclick="openDateModal(\'' . $dateStr . '\')"';
                                    } else {
                                        $cellAttrs = ' style="cursor:pointer;" onclick="window.location.href=\'book_date.php?date=' . $dateStr . '\'"';
                                    }
                                }
                                echo '<div class="calendar-cell ' . $cellClass . '" data-date="' . $dateStr . '"' . $cellAttrs . '>';
                                echo '<div class="date-num">' . $day . '</div>';
                                echo '<div class="label">' . $label . '</div>';
                                echo '</div>';
                            }
                        }
                        echo '</div>';
                    }
                }
                renderAdminCalendar($viewMonth, $viewYear, $bookedDates);
                ?>
            </div>
            <!-- Date modal for fully-booked dates (green header layout) -->
            <div id="dateModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.45);z-index:2000;align-items:center;justify-content:center">
                <div style="max-width:820px;width:92%;border-radius:8px;overflow:hidden;box-shadow:0 20px 60px rgba(0,0,0,0.4);background:transparent;">
                    <div style="background:var(--secondary-color);color:#fff;padding:12px 16px;display:flex;justify-content:space-between;align-items:center">
                        <h3 id="dateModalTitle" style="margin:0;font-weight:700">Booking status: <span id="modalDate"></span></h3>
                        <button onclick="closeDateModal()" style="background:transparent;border:none;color:#fff;font-weight:700;border-radius:4px;padding:6px 8px">✕</button>
                    </div>
                    <div style="background:#fff;padding:18px;">
                        <div style="display:flex;gap:24px;align-items:flex-start">
                            <div style="flex:1">
                                <div style="margin-bottom:10px"><strong>Status:</strong> <span id="modalStatus" style="display:inline-block;background:#f8e6c8;color:#6b4a00;padding:6px 10px;border-radius:8px;font-weight:800">Loading</span></div>
                                <div style="margin-bottom:8px;font-weight:700">Booked Times:</div>
                                <div id="modalBodyList" style="display:block;gap:8px"></div>
                            </div>
                        </div>
                    </div>
                    <div style="background:#fff;padding:12px 16px;display:flex;justify-content:flex-end;gap:8px">
                        <button id="cancelBtn" style="background:#f0f0f0;border-radius:6px;padding:8px 12px;border:none;color:#333">Cancel</button>
                        <button id="continueBtn" style="background:var(--secondary-color);color:#fff;border-radius:6px;padding:8px 12px;border:none;font-weight:700">Continue</button>
                    </div>
                </div>
            </div>
 
            <div class="calendar-actions" style="margin-top:18px; display:flex; gap:12px; align-items:center; justify-content:center;">
                 <?php if ($roleObj->canViewFinanceReport()): ?>
                     <a class="btn-primary-pill" href="finance_report.php?month=<?php echo $viewMonth; ?>&year=<?php echo $viewYear; ?>">📊 Monthly Finance Report</a>
                 <?php endif; ?>
             </div>
         </div>
     </div>
 </div>
 
 <!-- full-width fixed footer -->
 <footer class="site-footer" role="contentinfo">
     <div class="footer-left">
         <img src="assets/logo.png" alt="Marigold Logo">
         <div>
             <div class="sub-name">Marigold Subdivision</div>
             <div class="address">Phase 1 Marigold Subdivision Burgos, Rodriguez, Rizal.</div>
             <div class="contact">Contact: <a href="tel:0962620781" style="color:var(--primary-color);text-decoration:none;">0962620781</a></div>
         </div>
     </div>
     <div class="footer-links" aria-label="Footer links">
         <!-- Footer links removed for admin dashboard -->
     </div>
 </footer>
 
 <!-- Directions modal -->
 <div class="directions-modal-overlay" id="directionsModal" aria-hidden="true" role="dialog" aria-modal="true">
 	<div class="directions-modal-box">
 		<div class="directions-modal-header">
 			<h2>Directions to the Court</h2>
 			<button class="directions-modal-close" onclick="closeDirectionsModal()" aria-label="Close">&times;</button>
 		</div>
 		<div class="directions-modal-body">
 			<img src="assets/directions.png" alt="Directions to Court">
 		</div>
 	</div>
 </div>
 
 <!-- Layout modal -->
 <div class="layout-modal-overlay" id="layoutModal">
 	<div class="layout-modal-box">
 		<div class="layout-modal-header">
 			<h2>Layout of the Court</h2>
 			<button class="layout-modal-close" onclick="closeLayoutModal()">&times;</button>
 		</div>
 		<div class="layout-modal-body">
 			<img src="assets/layout_court.jpg" alt="Court Layout">
 		</div>
 	</div>
 </div>

<script>
    /* Directions inline open/close (admin) */
    function openDirectionsModal(e) {
        if (e) e.preventDefault();
        const el = document.getElementById('directionsInline');
        if (!el) return;
        el.classList.toggle('open');
        const open = el.classList.contains('open');
        el.setAttribute('aria-hidden', open ? 'false' : 'true');
        if (open) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
    function closeDirectionsModal() {
        const el = document.getElementById('directionsInline');
        if (!el) return;
        el.classList.remove('open');
        el.setAttribute('aria-hidden','true');
    }

   function openLayoutModal(e) {
 		e.preventDefault();
 		const modal = document.getElementById('layoutModal');
 		const container = document.querySelector('.calendar-page-container');
 		if (modal) {
 			modal.classList.add('open');
 			if (container) container.classList.add('modal-blur');
 		}
 	}
 	function closeLayoutModal() {
 		const modal = document.getElementById('layoutModal');
 		const container = document.querySelector('.calendar-page-container');
 		if (modal) {
 			modal.classList.remove('open');
 			if (container) container.classList.remove('modal-blur');
 		}
 	}
    // Close modal on background click
 	document.getElementById('layoutModal')?.addEventListener('click', function(e) {
 		if (e.target === this) closeLayoutModal();
 	});

    // Close directions modal on background click
    document.getElementById('directionsModal')?.addEventListener('click', function(e) {
        if (e.target === this) closeDirectionsModal();
    });

    // Date modal logic
    function openDateModal(dateStr) {
        const modal = document.getElementById('dateModal');
        const titleDate = document.getElementById('modalDate');
        const modalList = document.getElementById('modalBodyList');
        const modalStatus = document.getElementById('modalStatus');
        // Overwrite button removed from UI; server-side endpoint protected
        titleDate.textContent = dateStr;
        modal.style.display = 'flex';
        modalStatus.textContent = 'Loading';
        modalList.innerHTML = '<p>Loading…</p>';

        // Fetch bookings
        fetch('ajax_get_bookings.php?date=' + encodeURIComponent(dateStr))
            .then(r => r.json())
            .then(data => {
                if (!data.bookings) {
                    modalList.innerHTML = '<p>No bookings found for this date.</p>';
                    modalStatus.textContent = 'No bookings';
                    return;
                }
                // Compute whether this date is fully/partially booked
                let bookedMinutes = 0;
                const isSunday = (new Date(dateStr + 'T00:00:00')).getDay() === 0;
                function _normalizeTime(t) {
                    if (!t) return null;
                    const parts = t.split(':');
                    if (parts.length === 2) return parts[0].padStart(2,'0') + ':' + parts[1].padStart(2,'0') + ':00';
                    if (parts.length >= 3) return parts[0].padStart(2,'0') + ':' + parts[1].padStart(2,'0') + ':' + parts[2].padStart(2,'0');
                    return null;
                }
                data.bookings.forEach(b => {
                    try {
                        const sTime = _normalizeTime(b.startTime);
                        const eTime = _normalizeTime(b.endTime);
                        if (!sTime || !eTime) return;
                        const s = new Date(dateStr + 'T' + sTime);
                        const e = new Date(dateStr + 'T' + eTime);
                        if (!isNaN(s) && !isNaN(e)) bookedMinutes += Math.max(0, (e - s) / 60000);
                    } catch (ex) {}
                });
                // Total open minutes
                const _dayOfWeek = (new Date(dateStr + 'T00:00:00')).getDay();
                const openHour = _dayOfWeek === 6 ? 5 : 8; // base hour
                const openMinute = _dayOfWeek === 6 ? 30 : 0; // Saturday 05:30
                const openTime = new Date(dateStr + 'T' + String(openHour).padStart(2,'0') + ':' + String(openMinute).padStart(2,'0') + ':00');
                const closeTime = new Date(dateStr + 'T22:00:00');
                const totalMinutes = isSunday ? 0 : Math.max(0, (closeTime - openTime) / 60000);
                const isFully = (bookedMinutes >= totalMinutes && totalMinutes > 0);
                const isPartial = (!isFully && bookedMinutes > 0);

                modalStatus.textContent = isFully ? 'Fully Booked' : (isPartial ? 'Partially Booked' : 'Available');

                modalList.innerHTML = '';
                data.bookings.forEach(b => {
                    const row = document.createElement('div');
                    row.style.display = 'flex';
                    row.style.justifyContent = 'space-between';
                    row.style.alignItems = 'center';
                    row.style.padding = '8px 6px';
                    row.style.borderBottom = '1px solid #eee';
                    const left = document.createElement('div');
                    left.innerHTML = '<strong>#' + (b.id || '') + ' — ' + escapeHtml(b.name) + '</strong><div style="font-size:0.9rem;color:#666">' + b.date + ' (' + b.startTime + ' – ' + b.endTime + ')</div>';
                    const right = document.createElement('div');
                    right.style.display = 'flex';
                    right.style.gap = '8px';
                    // Delete button
                    const del = document.createElement('button');
                    del.textContent = 'Delete';
                    del.style.background = '#d9534f';
                    del.style.color = '#fff';
                    del.style.border = 'none';
                    del.style.padding = '6px 10px';
                    del.style.borderRadius = '6px';
                    del.onclick = function() {
                        if (!confirm('Delete this booking?')) return;
                        fetch('ajax_delete_booking.php', {method:'POST', headers: {'Content-Type':'application/x-www-form-urlencoded'}, body: 'id=' + encodeURIComponent(b.id)})
                            .then(r => r.json()).then(resp => {
                                if (resp.success) {
                                    // Close modal and update calendar cell status
                                    closeDateModal();
                                    fetch('ajax_get_bookings.php?date=' + encodeURIComponent(dateStr))
                                        .then(r2 => r2.json())
                                        .then(d2 => { updateCalendarCell(dateStr, d2.bookings || []); })
                                        .catch(()=>{});
                                } else {
                                    alert('Delete failed: ' + (resp.error || 'unknown'));
                                }
                            }).catch(e => { alert('Error'); });
                    };
                    right.appendChild(del);
                    row.appendChild(left);
                    row.appendChild(right);
                    modalList.appendChild(row);
                });

                // Overwrite action not exposed in modal UI

                // Cancel and Continue handlers
                document.getElementById('cancelBtn').onclick = closeDateModal;
                document.getElementById('continueBtn').onclick = function() {
                    if (isFully) {
                        alert('This date is fully booked. Please delete a timeslot to continue booking.');
                    } else {
                        // Partially booked/available: go to booking page to select remaining slots
                        window.location.href = 'book_date.php?date=' + encodeURIComponent(dateStr);
                    }
                };
            }).catch(e => {
                modalList.innerHTML = '<p>Error loading bookings</p>';
                modalStatus.textContent = 'Error';
            });
    }

    function closeDateModal() {
        const modal = document.getElementById('dateModal');
        modal.style.display = 'none';
    }

    function escapeHtml(str) {
        if (!str) return '';
        return str.replace(/[&<>\"']/g, function (c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; });
    }

    // Update calendar cell appearance for a given date based on bookings array
    function updateCalendarCell(dateStr, bookings) {
        try {
            const cell = document.querySelector('.calendar-cell[data-date="' + dateStr + '"]');
            if (!cell) return;
            const day = new Date(dateStr + 'T00:00:00');
            const isSunday = day.getDay() === 0;
            // total minutes open (Saturday opens at 05:30)
            const dow = day.getDay();
            const openHourBase = (dow === 6) ? 5 : 8;
            const openMinute = (dow === 6) ? 30 : 0;
            const openTime = new Date(dateStr + 'T' + String(openHourBase).padStart(2,'0') + ':' + String(openMinute).padStart(2,'0') + ':00');
            const closeTime = new Date(dateStr + 'T22:00:00');
            const totalMinutes = isSunday ? 0 : Math.max(0, (closeTime - openTime) / 60000);
            let bookedMinutes = 0;
            if (Array.isArray(bookings)) {
                function _norm(t) {
                    if (!t) return null;
                    const p = t.split(':');
                    if (p.length === 2) return p[0].padStart(2,'0') + ':' + p[1].padStart(2,'0') + ':00';
                    if (p.length >= 3) return p[0].padStart(2,'0') + ':' + p[1].padStart(2,'0') + ':' + p[2].padStart(2,'0');
                    return null;
                }
                bookings.forEach(b => {
                    try {
                        const sTime = _norm(b.startTime);
                        const eTime = _norm(b.endTime);
                        if (!sTime || !eTime) return;
                        const s = new Date(dateStr + 'T' + sTime);
                        const e = new Date(dateStr + 'T' + eTime);
                        if (!isNaN(s) && !isNaN(e)) bookedMinutes += Math.max(0, (e - s) / 60000);
                    } catch (ex) {}
                });
            }
            // determine status
            let statusClass = 'available';
            let label = 'Available';
            if (isSunday) { statusClass = 'closed'; label = 'Closed'; }
            else if (bookedMinutes >= totalMinutes && totalMinutes > 0) { statusClass = 'booked'; label = 'Booked'; }
            else if (bookedMinutes > 0) { statusClass = 'partial'; label = 'Partially Booked'; }

            // replace class
            cell.classList.remove('available','partial','booked','closed','past');
            cell.classList.add(statusClass);
            // update label element
            const lbl = cell.querySelector('.label');
            if (lbl) lbl.textContent = label;
        } catch (e) {
            console.error('updateCalendarCell error', e);
        }
    }
 </script>
 </body>
 </html>