<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once 'classes/Auth.php';
require_once 'classes/Role.php';
require_once 'classes/db.php';

$auth = new Auth();
if (!$auth->isLoggedIn()) {
    header('Location: login.php');
    exit;
}
$roleObj = new Role($auth->getRole());
if (!$roleObj->isSuperAdmin()) {
    http_response_code(403);
    echo 'Forbidden: only super-admins may view the activity log.';
    exit;
}

try {
    // Pagination
    $page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
    $perPage = 10;
    $offset = ($page - 1) * $perPage;

    // Total count
    $countStmt = $pdo->query('SELECT COUNT(*) AS cnt FROM activity_log');
    $total = (int)($countStmt->fetchColumn() ?: 0);
    $totalPages = (int)ceil($total / $perPage);

    $sql = 'SELECT a.id, a.booking_id, a.user_id, a.action, a.details, a.created_at,
                   b.date AS booking_date, b.start_time, b.end_time, b.name AS booking_name,
                   u.username AS actor_username
            FROM activity_log a
            LEFT JOIN bookings b ON a.booking_id = b.id
            LEFT JOIN users u ON a.user_id = u.id
            ORDER BY a.created_at DESC
            LIMIT :limit OFFSET :offset';
    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $rows = $stmt->fetchAll();
} catch (Exception $e) {
    $rows = [];
    $total = 0;
    $totalPages = 0;
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Activity Log - Marigold</title>
    <link rel="stylesheet" href="assets/css/styles.css">
    <style>
        :root{--primary:#1b3a0d;--accent:#2d5016;--bg:#cfd6d9;--card:#ffffff;--muted:#3d6b1f}
        /* Column layout so footer sits at bottom */
        html,body{height:100%;}
        body{display:flex;flex-direction:column;min-height:100vh;margin:0;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial;background:var(--bg);color:var(--primary)}
        main{flex:1}
        .page-header{display:flex;align-items:center;justify-content:space-between;padding:16px 40px;background:var(--accent);color:#fff;border-bottom:2px solid rgba(0,0,0,0.06);position:relative}
        .header-center{position:absolute;left:50%;transform:translateX(-50%);font-weight:700;color:#fff;letter-spacing:1px;font-size:1.3rem}
        .header-right{display:flex;gap:16px;align-items:center}
        .header-link{background:#fff;color:var(--accent);padding:8px 12px;border-radius:8px;text-decoration:none;font-weight:700}
        /* Increase font-size in container */
        .container{max-width:1600px;margin:24px auto;padding:36px;background:var(--card);border-radius:14px;box-shadow:0 22px 60px rgba(0,0,0,0.08);font-size:1.0rem}
        .container h2{margin:0 0 8px 0;text-align:center;font-size:1.6rem;color:var(--accent);font-weight:800;letter-spacing:1px}
        .container .title-decor{display:block;margin:8px auto 18px auto;width:80px;height:6px;background:linear-gradient(90deg,var(--accent),#79a561);border-radius:6px}
        table{width:100%;border-collapse:collapse;font-size:inherit}
        th,td{padding:12px;border-bottom:1px solid #eee;text-align:left}
        th{background:#fafafa;color:var(--primary);font-weight:700;font-size:1.03em}
        /* Header label row styling */
        .col-labels th { background:#fafafa;color:#666;font-weight:800;font-size:0.95rem }
        .muted{color:#666;margin-bottom:12px}
        .site-footer{margin-top:auto;background:var(--card);border-top:2px solid var(--accent);padding:18px 36px}
    </style>
</head>
<body>
<header class="page-header" role="banner">
    <div></div>
    <div class="header-center">MARIGOLD SUBDIVISION COURT BOOKING</div>
    <div class="header-right">
        <span style="color:#fff;font-weight:600">Welcome, <strong><?php echo htmlspecialchars($auth->getUsername()); ?></strong></span>
        <?php if ($roleObj->canManageUsers()): ?>
            <a href="create_user.php" class="header-link">➕ Create Account</a>
        <?php endif; ?>
        <a href="dashboard_admin.php" class="header-link">← Dashboard</a>
        <a href="logout.php" class="header-link">🚪 Logout</a>
    </div>
</header>

<main>
    <div class="container">
        <h2>Activity Log</h2>
        <div class="muted">Recent booking activity (create / cancelled) with booking details when available.</div>

        <!-- Legend -->

        <table aria-label="Activity log">
            <thead>
                <!-- Header labels -->
                <tr class="col-labels">
                    <th>Identifier</th>
                    <th>Event</th>
                    <th>Booking Ref</th>
                    <th>Booking Time</th>
                    <th>Performed By</th>
                    <th>Notes / Details</th>
                    <th>Timestamp</th>
                </tr>
                <!-- Header cell -->
            </thead>
            <tbody>
            <?php if (empty($rows)): ?>
                <tr><td colspan="7">No activity recorded.</td></tr>
            <?php else: ?>
                <?php foreach ($rows as $r): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($r['id']); ?></td>
                        <td><?php echo htmlspecialchars($r['action']); ?></td>
                        <td>
                            <?php
                                        // Booking ref: show booking id or parse details
                                        if (!empty($r['booking_id'])) {
                                            echo '#' . htmlspecialchars($r['booking_id']);
                                        } else {
                                            $ref = null;
                                            if (!empty($r['details']) && preg_match('/#(\d+)/', $r['details'], $mref)) $ref = $mref[1];
                                            if ($ref) echo '#' . htmlspecialchars($ref);
                                            else echo '—';
                                        }
                            ?>
                        </td>
                        <td>
                            <?php
                                // Booking time: prefer joined fields, else parse details
                                if (!empty($r['booking_date'])) {
                                    echo htmlspecialchars($r['booking_date']);
                                    if (!empty($r['start_time']) && !empty($r['end_time'])) {
                                        echo ' (' . htmlspecialchars($r['start_time']) . '–' . htmlspecialchars($r['end_time']) . ')';
                                    }
                                } else {
                                    $timeFound = false;
                                    if (!empty($r['details'])) {
                                        if (preg_match('/(\d{4}-\d{2}-\d{2})\s+(\d{2}:\d{2})-(\d{2}:\d{2})/', $r['details'], $mt)) {
                                            echo htmlspecialchars($mt[1]) . ' (' . htmlspecialchars($mt[2]) . '–' . htmlspecialchars($mt[3]) . ')';
                                            $timeFound = true;
                                        }
                                    }
                                    if (!$timeFound) echo '—';
                                }
                            ?>
                        </td>
                        <td><?php echo htmlspecialchars($r['actor_username'] ?? $r['user_id'] ?? ''); ?></td>
                        <td><?php echo htmlspecialchars($r['details']); ?></td>
                        <td><?php echo htmlspecialchars($r['created_at']); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>

        <!-- Pagination controls -->
        <?php if ($totalPages > 1): ?>
            <nav aria-label="Activity log pagination" style="margin-top:16px;display:flex;justify-content:center;align-items:center;gap:8px">
                <?php if ($page > 1): ?>
                    <a href="?page=<?php echo $page - 1; ?>" style="padding:8px 12px;background:#fff;border-radius:6px;text-decoration:none;border:1px solid #ddd">← Prev</a>
                <?php else: ?>
                    <span style="padding:8px 12px;color:#999">← Prev</span>
                <?php endif; ?>

                <?php for ($p = 1; $p <= $totalPages; $p++): ?>
                    <?php if ($p == $page): ?>
                        <span style="padding:8px 12px;background:var(--accent);color:#fff;border-radius:6px;font-weight:700"><?php echo $p; ?></span>
                    <?php else: ?>
                        <a href="?page=<?php echo $p; ?>" style="padding:8px 12px;background:#fff;border-radius:6px;text-decoration:none;border:1px solid #ddd"><?php echo $p; ?></a>
                    <?php endif; ?>
                <?php endfor; ?>

                <?php if ($page < $totalPages): ?>
                    <a href="?page=<?php echo $page + 1; ?>" style="padding:8px 12px;background:#fff;border-radius:6px;text-decoration:none;border:1px solid #ddd">Next →</a>
                <?php else: ?>
                    <span style="padding:8px 12px;color:#999">Next →</span>
                <?php endif; ?>
            </nav>
        <?php endif; ?>
    </div>
</main>

<!-- Footer -->
<footer class="site-footer" role="contentinfo">
    <div class="footer-left">
        <img src="assets/logo.png" alt="Marigold Logo" style="height:80px;display:block;margin-right:12px">
        <div>
            <div style="font-weight:700;color:var(--primary)">Marigold Subdivision</div>
            <div style="color:var(--muted)">Phase 1 Marigold Subdivision Burgos, Rodriguez, Rizal.</div>
            <div style="font-weight:700;color:var(--primary);margin-top:6px">Contact: <a href="tel:0962620781" style="color:var(--primary);text-decoration:none;">0962620781</a></div>
        </div>
    </div>
    <div class="footer-links" aria-label="Footer links"></div>
</footer>

</body>
</html>
