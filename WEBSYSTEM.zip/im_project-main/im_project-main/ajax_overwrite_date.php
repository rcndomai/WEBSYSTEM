<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once 'classes/Auth.php';
require_once 'classes/Role.php';
require_once 'classes/BookingManager.php';

$auth = new Auth();
if (!$auth->isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Not authenticated']);
    exit;
}
$role = new Role($auth->getRole());
if (!$role->canOverwrite()) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Forbidden']);
    exit;
}

$date = $_POST['date'] ?? null;
if (!$date) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Missing date']);
    exit;
}

$mgr = new BookingManager();
$ok = $mgr->deleteBookingsByDate($date);

header('Content-Type: application/json');
echo json_encode(['success' => (bool)$ok]);
exit;
?>
