<?php
session_start();
$bookingSummary = isset($_SESSION['last_booking_summary']) ? $_SESSION['last_booking_summary'] : null;
if ($bookingSummary) {
    unset($_SESSION['last_booking_summary']);
}

// Booking timestamp
$bookedAtDisplay = (new DateTime('now', new DateTimeZone('Asia/Manila')))->format('F j, Y g:i A');
if ($bookingSummary && !empty($bookingSummary['booked_at'])) {
    try {
        $dt = new DateTime($bookingSummary['booked_at'], new DateTimeZone('Asia/Manila'));
        $bookedAtDisplay = $dt->format('F j, Y g:i A');
    } catch (Exception $e) {
        $bookedAtDisplay = htmlspecialchars($bookingSummary['booked_at']);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marigold Subdivision Court Booking - Pricing Info</title>
    <link rel="stylesheet" href="assets/css/styles.css">
    <style>
        :root{
            --primary:#1b3a0d;
            --accent:#2d5016;
            --bg:#cfd6d9;
            --card:#ffffff;
            --muted:#3d6b1f;
        }
        *{box-sizing:border-box;color:var(--primary);}
        body{margin:0;background:var(--bg);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial}
        .page-header{display:flex;align-items:center;justify-content:space-between;padding:16px 40px;background:var(--accent);color:#ffffff;border-bottom:2px solid rgba(0,0,0,0.06)}
        .header-left{width:120px}
        .header-center{flex:1;text-align:center;font-weight:700;color:#ffffff;letter-spacing:1px;font-size:1.3rem}
        .header-right{width:auto;display:flex;justify-content:flex-end;align-items:center;gap:16px;font-size:1rem}
        .header-btn{background:#ffffff;color:var(--accent);padding:10px 20px;border-radius:10px;text-decoration:none;font-weight:700;border:2px solid rgba(255,255,255,0.85)}
        .header-btn:hover{background:#f0f0f0;transform:scale(1.03)}

        /* Layout */
        .pricing-wrap { max-width: 1100px; margin: 18px auto 120px; padding: 18px; display:flex; gap:18px; align-items:stretch; justify-content:center; background: transparent; }
        /* Card */
        .pricing-card { width:100%; display:flex; gap:18px; background: var(--card); border-radius:12px; padding:18px; box-shadow:0 12px 30px rgba(0,0,0,0.06); border:2px solid rgba(0,0,0,0.04); align-items:stretch; }
        .pricing-container { flex: 1 1 560px; background: transparent; border-radius: 8px; padding: 8px 6px; }
        /* Receipt panel */
        .receipt-side { flex: 0 0 360px; margin-top:0; display:flex; align-items:flex-start; }
        .receipt { width:100%; }
        @media(max-width:900px){ .pricing-wrap { padding:12px } .pricing-card{flex-direction:column;} .receipt-side{width:100%;} }
        h1 { color: var(--accent); text-align: center; margin-bottom: 12px; }
        h2 { color: var(--muted); margin-top: 18px; }
        ul { margin: 0 0 18px 24px; }
        .note { background: #fffbe6; border-left: 4px solid #ffe066; padding: 12px 16px; border-radius: 6px; margin: 18px 0; color: #b8860b; }
        .back-btn { display: inline-block; margin-top: 18px; padding: 10px 18px; background: var(--accent); color: #fff; border-radius: 8px; font-size: 1rem; font-weight: 700; text-decoration: none; transition: background 0.15s; }
        .back-btn:hover { background: var(--primary); }

        /* Receipt */
        .receipt { background: #f7fbf6; border: 1px dashed rgba(45,80,22,0.12); padding: 14px 16px; border-radius: 8px; margin-bottom: 14px; }
        .receipt .line { display:flex; justify-content:space-between; gap:12px; padding:6px 0; }
        .receipt .line strong{color:var(--primary)}

        .site-footer { width:100%; box-sizing:border-box; background:var(--card); border-top:2px solid var(--accent); padding:18px 36px; display:flex; gap:20px; align-items:flex-start; justify-content:space-between; position:fixed; left:0; right:0; bottom:0; z-index:1000; }
        .site-footer .footer-left img { height:70px; width:auto; display:block; }
        .site-footer .footer-left { display:flex; gap:12px; align-items:center; }
        .site-footer .contact { font-weight:700; color:var(--primary); margin-top:6px; }
        @media(max-width:760px){ .site-footer{flex-direction:column;align-items:flex-start} .site-footer .footer-links{margin-top:12px} }
    </style>
</head>
<body>
    <header class="page-header" role="banner">
        <div class="header-left"></div>
        <div class="header-center">MARIGOLD SUBDIVISION COURT BOOKING</div>
        <div class="header-right">
            <a href="dashboard_admin.php" class="header-btn">&larr; Dashboard</a>
        </div>
    </header>

    <div class="pricing-wrap">
        <div class="pricing-card">
        <?php if ($bookingSummary): ?>
        <div class="receipt-side">
            <div class="receipt" aria-hidden="false">
                <h2 style="margin:0 0 8px 0;color:var(--accent);">Booking Receipt</h2>
                <div class="line"><div><strong>Booked On</strong></div><div><?php echo htmlspecialchars($bookedAtDisplay); ?></div></div>
                <div class="line"><div><strong>Date</strong></div><div><?php echo htmlspecialchars($bookingSummary['date']); ?></div></div>
                <div class="line"><div><strong>Time</strong></div><div><?php echo htmlspecialchars($bookingSummary['start']); ?> - <?php echo htmlspecialchars($bookingSummary['end']); ?></div></div>
                <div class="line"><div><strong>Name</strong></div><div><?php echo htmlspecialchars($bookingSummary['name']); ?></div></div>
                <div class="line"><div><strong>Reason</strong></div><div><?php echo htmlspecialchars($bookingSummary['reason']); ?></div></div>

                <?php
                // Time breakdown calc
                $startTime = $bookingSummary['start']; // time
                $endTime = $bookingSummary['end'];     // time
                $isHomeowner = $bookingSummary['isHomeowner'] ?? false;
                $hasElectricity = $bookingSummary['electricity'] ?? false;

                $startHour = (int)substr($startTime, 0, 2);
                $endHour = (int)substr($endTime, 0, 2);

                // Morning/evening hour calc
                $morningStart = max(8, $startHour);
                $morningEnd = min(17, $endHour);
                $morningHours = max(0, $morningEnd - $morningStart);

                $eveningStart = max(17, $startHour);
                $eveningEnd = min(22, $endHour);
                $eveningHours = max(0, $eveningEnd - $eveningStart);

                // Rates
                if ($isHomeowner) {
                    $morningRate = 0;  // Free
                    $eveningRate = 200; // 200 per hour
                } else {
                    $morningRate = 75;
                    if ($hasElectricity) $morningRate += 25; // 100 total with electricity
                    $eveningRate = 250;
                }

                $morningCost = $morningHours * $morningRate;
                $eveningCost = $eveningHours * $eveningRate;
                $totalCost = $morningCost + $eveningCost;
                // Service fee
                $serviceFee = 50;
                $totalCost += $serviceFee;
                ?>

                <div style="margin-top:12px;padding-top:12px;border-top:1px dashed rgba(45,80,22,0.2);">
                    <div style="font-weight:700;color:var(--accent);margin-bottom:8px;">Rate Breakdown</div>
                    <?php if ($morningHours > 0): ?>
                        <div class="line" style="font-size:0.95rem;">
                            <div>Morning (08:00-17:00): <?php echo $morningHours; ?>h @ ₱<?php echo $morningRate; ?>/hr<?php echo ($isHomeowner ? " (homeowner)" : ($hasElectricity ? " (with electricity)" : "")); ?></div>
                            <div>₱<?php echo number_format($morningCost, 2); ?></div>
                        </div>
                    <?php endif; ?>
                    <?php if ($eveningHours > 0): ?>
                        <div class="line" style="font-size:0.95rem;">
                            <div>Evening (17:00-22:00): <?php echo $eveningHours; ?>h @ ₱<?php echo $eveningRate; ?>/hr<?php echo ($isHomeowner ? " (homeowner)" : ""); ?></div>
                            <div>₱<?php echo number_format($eveningCost, 2); ?></div>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="line" style="margin-top:12px;font-size:1.05rem;"><div><strong>Service Fee</strong></div><div>₱<?php echo number_format($serviceFee,2); ?></div></div>
                <div class="line" style="margin-top:8px;font-size:1.05rem;"><div><strong>Total Amount Due</strong></div><div style="color:#b00000;font-weight:700;">₱<?php echo number_format($totalCost, 2); ?></div></div>
            </div>
        </div>
        <?php endif; ?>

        <div class="pricing-container">
        <h1>Marigold Subdivision Court Booking</h1>
        <h2>Normal Rates</h2>
        <ul>
            <li><strong>Morning to Afternoon:</strong> ₱75/hr <span style="color:#888;">(+₱25/hr for electricity)</span> <br><span style="font-size:0.95em;color:#888;">Total: ₱100/hr</span></li>
            <li><strong>Evenings:</strong> ₱250/hr <span style="color:#888;">(electricity included)</span></li>
        </ul>
        <h2>Homeowners</h2>
        <ul>
            <li><strong>Morning to Afternoon:</strong> <span style="color:green;">Free</span></li>
            <li><strong>Evening:</strong> ₱200/hr</li>
        </ul>
        <h2>Reservation Fee</h2>
        <ul>
            <li><strong>Downpayment:</strong> ₱50 (deducted from total fee)</li>
        </ul>
        <div class="note">
            <strong>Note:</strong> If a reservation is cancelled, the ₱50 downpayment will <u>not</u> be refunded.
        </div>
        <!-- back button -->
        </div>
        </div>

    <!-- full-width site footer -->
    <footer class="site-footer" role="contentinfo">
         <div class="footer-left">
             <img src="assets/logo.png" alt="Marigold Logo">
             <div>
                 <div class="sub-name">Marigold Subdivision</div>
                 <div class="address">Phase 1 Marigold Subdivision Burgos, Rodriguez, Rizal.</div>
                 <div class="contact">Contact: <a href="tel:0962620781" style="color:var(--primary);text-decoration:none;">0962620781</a></div>
             </div>
         </div>
             <div class="footer-links" aria-label="Footer links">
             <!-- footer links -->
         </div>
    </footer>
</body>
</html>
