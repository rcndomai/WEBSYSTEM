<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once "classes/Auth.php";
require_once "classes/BookingManager.php";
require_once "classes/Role.php";

$auth = new Auth();
$manager = new BookingManager();

if (!$auth->isLoggedIn()) {
    header('Location: login.php');
    exit;
}

// User role
$role = $auth->getRole();

// Role helper
$userRole = new Role($role);

$isAdmin = $userRole->isAdmin();
$isSecretary = $userRole->isSecretary();
$isUser = $userRole->isUser();
$canManageBookings = $userRole->canManageBookings();
$canDeleteAll = $userRole->canDeleteAll();
$canOverwrite = $userRole->canOverwrite();

// AJAX: delete all bookings for date
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete_all' && !empty($_POST['date'])) {
    header('Content-Type: application/json');
    if (!$userRole->canDeleteAll()) {
        echo json_encode(['success' => false, 'error' => 'Permission denied. Only admins can delete all bookings.']);
        exit;
    }
    $delDate = $_POST['date'];
    $result = ['success' => false];
    $deleted = false;
    if (method_exists($manager, 'deleteBookingsByDate')) {
        $deleted = $manager->deleteBookingsByDate($delDate);
    } elseif (method_exists($manager, 'removeBookingsForDate')) {
        $deleted = $manager->removeBookingsForDate($delDate);
    } elseif (method_exists($manager, 'deleteAllByDate')) {
        $deleted = $manager->deleteAllByDate($delDate);
    } elseif (method_exists($manager, 'deleteByDate')) {
        $deleted = $manager->deleteByDate($delDate);
    } else {
        $result['error'] = 'Delete-all method not available on BookingManager.';
    }
    $result['success'] = (bool)$deleted;
    echo json_encode($result);
    exit;
}
// end ajax delete-all

// AJAX: delete single booking
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete' && !empty($_POST['id'])) {
    header('Content-Type: application/json');
    if (!$userRole->canDeleteBooking()) {
        echo json_encode(['success' => false, 'error' => 'Permission denied.']);
        exit;
    }
    $id = intval($_POST['id']);
    $result = ['success' => false, 'id' => $id];
    $deleted = false;
    $userId = $auth->getUserId();
    if (method_exists($manager, 'deleteBookingByUser')) {
        try { $deleted = (bool)$manager->deleteBookingByUser($id, $userId); } catch (Exception $e) { $result['error'] = $e->getMessage(); }
    } elseif (method_exists($manager, 'deleteBooking')) {
        try { $deleted = (bool)$manager->deleteBooking($id); } catch (Exception $e) { $result['error'] = $e->getMessage(); }
    } elseif (method_exists($manager, 'removeBookingById')) {
        try { $deleted = (bool)$manager->removeBookingById($id); } catch (Exception $e) { $result['error'] = $e->getMessage(); }
    } else {
        $result['error'] = 'Delete method not available on BookingManager.';
    }
    $result['success'] = (bool)$deleted;
    echo json_encode($result);
    exit;
}
// end ajax delete-one

// Redirect non-admin users
if ($userRole->isUser()) {
    header('Location: dashboard_admin.php');
    exit;
}

$manager = new BookingManager();
$date = $_GET['date'] ?? '';
$error = '';
$conflictOccurred = false; // conflict flag

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Permission check: create bookings
    if (!$userRole->canManageBookings()) {
        $error = 'Permission denied. Only admins and secretaries can create bookings.';
    } else {
        $name = $_POST['name'] ?? '';
        $reason = $_POST['reason'] ?? '';
        $isPaid = isset($_POST['is_paid']) && $_POST['is_paid'] == '1' ? 1 : 0;
        $start = $_POST['start_time'] ?? '';
        $end = $_POST['end_time'] ?? '';
        $isHomeowner = isset($_POST['is_homeowner']) && $_POST['is_homeowner'] == '1' ? true : false;
        $electricity = isset($_POST['electricity']) && $_POST['electricity'] == '1' ? true : false;
        if (empty($name) || empty($reason) || empty($start) || empty($end)) {
            $error = 'Please fill in all fields.';
        } elseif ($start >= $end) {
            $error = 'End time must be later than start time.';
        } elseif ((strtotime($end) - strtotime($start)) % 3600 !== 0) {
            $error = 'Bookings must be in whole hour increments.';
        } else {
            // Overlap check
            $existing = $manager->getBookings();
            $conflict = false;
            foreach ($existing as $b) {
                if ($b->date === $date) {
                    // Check time overlap with existing booking
                    if (!(strtotime($end) <= strtotime($b->startTime) || strtotime($start) >= strtotime($b->endTime))) {
                        $conflict = true;
                        break;
                    }
                }
            }
            if ($conflict) {
                $error = 'This time slot is already booked. Please choose another.';
                $conflictOccurred = true; // conflict
            } else {
                $booking = new Booking($date, $start, $end, $name, $isPaid, $reason, $isHomeowner, $electricity);
                // Create booking (logs activity)
                $userId = $auth->getUserId();
                if (method_exists($manager, 'createBookingByUser')) {
                    $manager->createBookingByUser($userId, $booking);
                } else {
                    $manager->addBooking($booking);
                }
                // Clean session bookings
                if (isset($_SESSION['bookings'])) {
                    $_SESSION['bookings'] = array_filter($_SESSION['bookings'], function($b) {
                        return is_object($b) && property_exists($b, 'date');
                    });
                }
                // Save booking summary
                $bookedAtTime = (new DateTime('now', new DateTimeZone('Asia/Manila')))->format('F j, Y g:i A');
                $_SESSION['last_booking_summary'] = [
                    'date' => $date,
                    'start' => $start,
                    'end' => $end,
                    'name' => $name,
                    'isPaid' => $isPaid,
                    'reason' => $reason,
                    'isHomeowner' => $isHomeowner,
                    'electricity' => $electricity,
                    'total' => $booking->totalPrice,
                    'rate' => $booking->ratePerHour,
                    'hours' => max(1, ceil((strtotime($end) - strtotime($start))/3600)),
                    'booked_at' => $bookedAtTime,
                ];
                // Booking success: redirect to receipt
                $_SESSION['booking_success'] = true;
                // Redirect to pricing_info.php
                header('Location: pricing_info.php');
                exit;
            }
        }
    }
}

// Ensure start/end variables
if (!isset($start)) $start = '';
if (!isset($end)) $end = '';

// Time range settings
$minTime = '08:00';
$maxTime = '22:00';
$minTimeWeekend = '05:00';
$dateObj = DateTime::createFromFormat('Y-m-d', $date);
$isWeekend = $dateObj && (in_array($dateObj->format('w'), ['0', '6']));
$min = $isWeekend ? $minTimeWeekend : $minTime;
$max = $maxTime;

// Collect bookings for date
$dateBookings = [];
$existing = $manager->getBookings();
foreach ($existing as $b) {
    if ($b->date === $date) {
        $dateBookings[] = $b;
    }
}
$startHour = $isWeekend ? 5 : 8;
$totalAvailableHours = $maxHour = 22 - $startHour;
$bookedHours = 0;
foreach ($dateBookings as $b) {
    $bookedHours += max(0, (strtotime($b->endTime) - strtotime($b->startTime)) / 3600);
}
$fullyBooked = ($bookedHours >= $totalAvailableHours && $totalAvailableHours > 0);
$partiallyBooked = (!$fullyBooked && count($dateBookings) > 0);

// Restrict non-admin when fully booked
if ($fullyBooked && !$userRole->isAdmin()) {
    $_SESSION['flash_message'] = "Date " . htmlspecialchars($date) . " is fully booked. Only admins can overwrite.";
    header('Location: dashboard_admin.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Date - Marigold</title>
    <link rel="stylesheet" href="assets/css/styles.css">
    <style>
        :root {
            --primary:#1b3a0d;
            --accent:#2d5016;
            --bg:#cfd6d9;
            --card:#ffffff;
            --muted:#3d6b1f;
        }
        /* Header styles matching dashboard.php */
        .page-header{display:flex;align-items:center;justify-content:space-between;padding:14px 48px;background:var(--accent);color:#ffffff;border-bottom:2px solid rgba(0,0,0,0.06)}
        .header-left{width:160px}
        .header-center{flex:1;text-align:center;font-weight:700;color:#ffffff;letter-spacing:1px;font-size:1.4rem}
        .header-right{width:auto;display:flex;justify-content:flex-end;align-items:center;gap:16px;font-size:1rem}
        .header-btn{background:#ffffff;color:var(--accent);padding:10px 20px;border-radius:10px;text-decoration:none;font-weight:700;border:2px solid rgba(255,255,255,0.85)}
        .header-btn:hover{background:#f0f0f0;transform:scale(1.03)}
        /* Footer styles matching dashboard.php */
        .site-footer { width:100%; box-sizing:border-box; background:var(--card); border-top:2px solid var(--accent); padding:18px 36px; display:flex; gap:20px; align-items:flex-start; justify-content:space-between; position:fixed; left:0; right:0; bottom:0; z-index:1000; }
        .site-footer .footer-left img { height:90px; width:auto; display:block; }
        .site-footer .footer-left { display:flex; align-items:flex-start; gap:12px; }
        .site-footer .sub-name { font-weight:700; color:var(--primary); font-size:1.2rem; }
        .site-footer .address { color:var(--muted); font-size:1.05rem; margin-top:6px; }
        .site-footer .contact { margin-top:6px; font-weight:700; color:var(--primary); font-size:1.05rem; }
        .site-footer .footer-links { margin-left:12px; }
        .site-footer .footer-links ul { margin:0; padding-left:0; color:var(--primary); display:flex; flex-direction:column; gap:4px; }
        .site-footer .footer-links li { margin:0; font-weight:700; font-size:1rem; }
        .site-footer .footer-links a { color:var(--primary); text-decoration:none; }
        .site-footer .footer-links a:hover { color:var(--accent); }
        * { color: var(--text-color); box-sizing: border-box; }
        body { background: var(--background-gray); margin: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial; }

        .book-date-container { min-height: calc(100vh - 120px); display: flex; align-items: center; justify-content: center; padding: 20px 40px; background: var(--bg); box-sizing: border-box; }
        .book-date-box { background: var(--card); padding: 40px; border-radius: 8px; border: 2px solid rgba(0,0,0,0.06); box-shadow: 0 6px 20px rgba(0,0,0,0.08); max-width: 920px; width: 100%; margin: 0; font-size: 1.05rem; }
        .book-date-box h2 { text-align: center; color: var(--accent); margin-bottom: 18px; font-size: 1.5rem; font-weight: 700; }
        .book-date-box h3 { text-align: left; color: var(--accent); margin-bottom: 12px; margin-top: 6px; font-size: 1.05rem; font-weight: 600; }
        .book-date-box form { display: flex; flex-direction: column; width: 100%; }
        .step { display: flex; flex-direction: column; gap: 8px; width: 100%; }
        .book-date-box label { display: block; font-weight: 600; color: var(--primary-color); font-size: 0.95rem; }
        .book-date-box select, .book-date-box input[type="text"], .book-date-box input[type="time"] {
            width: 100%; padding: 10px; margin-top: 6px; border-radius: 6px; border: 1px solid #d0d7db; background: #fbfdff;
        }
        .invalid { border-color: var(--error-color) !important; box-shadow: 0 0 0 3px rgba(231,76,60,0.08); }
        .field-error { color: var(--error-color); font-size: 0.9rem; margin-top:6px; display:none; }
        .book-date-box .button-group { display: flex; gap: 12px; justify-content: space-between; margin-top: 16px; }
        .book-date-box .button-group button { flex: 1; padding: 10px; border-radius: 6px; border: none; cursor: pointer; background: var(--accent); color: #fff; font-weight: 700; }
        .book-date-box .button-group button:hover { background: var(--primary); }
        .book-date-box .back-inline { display:block; text-align:center; margin-top:16px; color:var(--accent); text-decoration:none; font-weight:600; }
        /* left-align Yes/No labels with the radio dot directly beside the text */
        .radio-group { margin-top: 8px; display: flex; flex-direction: column; gap: 10px; align-items: flex-start; }
        .radio-group label { display:flex; align-items:center; gap:8px; cursor:pointer; font-weight:600; color:var(--muted); flex-direction: row-reverse; /* text left, dot right */ }
        .radio-group input[type="radio"] { margin-left: 8px; margin-right: 0; }
        .booked-info { background:#f6f7f8; border:1px dashed #bfc7cb; padding:10px; border-radius:6px; margin-bottom:12px; font-size:0.95rem; color:var(--muted); }
         .error { background-color: #fdecea; color: #b71c1c; padding: 10px; border-radius: 6px; margin-bottom: 12px; text-align: center; }

        /* Modal overlay and box (matches page style) */
        .modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.55); display: none; align-items: center; justify-content: center; z-index: 99999; padding: 20px; }

        /* dim/disable background when modal open */
        .modal-open .book-date-box {
            filter: blur(4px) grayscale(12%);
            opacity: 0.35;
            pointer-events: none;
            user-select: none;
        }
        .modal-box { background: var(--card); padding: 0; border-radius: 12px; box-shadow: 0 20px 60px rgba(0,0,0,0.25); max-width: 640px; width: 100%; z-index:100000; overflow:hidden; }
        .modal-header { background:var(--accent); color:#fff; padding:14px 18px; font-size:1.15rem; font-weight:700; margin:0; display:flex; align-items:center; justify-content:space-between; }
        .modal-body { padding:18px; color:var(--muted); }
        .modal-actions { padding: 14px 18px; display:flex; gap:12px; justify-content:flex-end; }

        /* Buttons matching dashboard */
        .btn-primary { background: var(--accent); color: #fff; padding: 10px 16px; border-radius: 8px; border: none; font-weight:700; cursor:pointer; }
        .btn-primary:hover { background: var(--primary); }
        .btn-destructive { background:#e74c3c; color:#fff; padding:10px 14px; border-radius:8px; border:none; font-weight:700; cursor:pointer; }
        .btn-cancel { background:#f0f0f0; color:#333; padding:10px 14px; border-radius:8px; border:1px solid rgba(0,0,0,0.06); cursor:pointer; }
        .modal-body { margin-top: 8px; font-size: 0.98rem; color: var(--muted); }
        .status-badge { display:inline-block; padding:6px 10px; border-radius:6px; font-weight:700; margin-left:8px; }
        .status-available { background:#e6fffa; color:#0b6b5a; border:1px solid #bfeee0; }
        .status-partial { background:#fff4db; color:#8a5d00; border:1px solid #f1dca3; }
        .status-full { background:#ffecec; color:#8b1b1b; border:1px solid #f2b6b6; }

        /* color the booking card: partial = light yellow, full = light red */
        .book-date-box.partial { background: #fff4db; border-color: #f1dca3; }
        .book-date-box.full { background: #ffecec; border-color: #f2b6b6; }

        /* Receipt Modal Styles */
        .receipt-modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.65); display: none; align-items: center; justify-content: center; z-index: 100001; padding: 20px; }
        .receipt-modal-overlay.show { display: flex; }
        .receipt-modal-box { background: var(--card); border-radius: 16px; box-shadow: 0 25px 80px rgba(0,0,0,0.3); max-width: 700px; width: 100%; overflow: hidden; }
        .receipt-header { background: linear-gradient(135deg, var(--accent) 0%, var(--primary) 100%); color: #fff; padding: 28px 24px; text-align: center; border-bottom: 3px solid #e8f0e0; }
        .receipt-header h2 { margin: 0 0 4px 0; font-size: 2rem; font-weight: 700; letter-spacing: 2px; }
        .receipt-header p { margin: 0; font-size: 0.95rem; opacity: 0.95; font-weight: 500; }
        .receipt-content { padding: 32px 28px; background: #f9fbf9; max-height: 70vh; overflow-y: auto; }
        .receipt-line { display: flex; justify-content: space-between; align-items: center; padding: 10px 0; border-bottom: 1px solid rgba(45,80,22,0.1); font-size: 1rem; }
        .receipt-line:last-child { border-bottom: none; }
        .receipt-line-label { font-weight: 600; color: var(--primary); }
        .receipt-line-value { color: var(--muted); text-align: right; }
        .receipt-section { margin-top: 20px; }
        .receipt-section-title { font-weight: 700; color: var(--accent); font-size: 1.05rem; margin-bottom: 10px; padding-bottom: 8px; border-bottom: 2px solid var(--accent); }
        .receipt-total { background: #e6fffa; border-radius: 8px; padding: 16px; margin-top: 16px; display: flex; justify-content: space-between; align-items: center; }
        .receipt-total-label { font-weight: 700; font-size: 1.1rem; color: var(--primary); }
        .receipt-total-amount { font-weight: 700; font-size: 1.3rem; color: #0b6b5a; }
        .receipt-actions { padding: 20px 28px; display: flex; gap: 12px; justify-content: space-between; background: #f0f8e8; border-top: 2px solid rgba(45,80,22,0.1); }
        .receipt-btn { padding: 12px 20px; border-radius: 8px; border: none; font-weight: 700; font-size: 1rem; cursor: pointer; transition: all 0.2s; }
        .receipt-btn-print { background: var(--accent); color: #fff; flex: 1; }
        .receipt-btn-print:hover { background: var(--primary); transform: translateY(-2px); }
        .receipt-btn-continue { background: #e6fffa; color: var(--accent); flex: 1; }
        .receipt-btn-continue:hover { background: #d4f0ed; transform: translateY(-2px); }
        .receipt-note { background: #fffbe6; border-left: 4px solid #ffe066; padding: 12px 14px; border-radius: 6px; margin-top: 14px; color: #8a5d00; font-size: 0.95rem; }
    </style>
    </head>
    <body class="no-court-bg">
    <header class="page-header" role="banner">
        <div class="header-left"></div>
        <div class="header-center">MARIGOLD SUBDIVISION COURT BOOKING</div>
        <div class="header-right">
            <?php $headerUser = $_SESSION['username'] ?? $_SESSION['user_name'] ?? null; ?>
            <?php if ($headerUser): ?>
                <span style="font-size:1rem;color:#ffffff;font-weight:600">Welcome, <strong><?php echo htmlspecialchars($headerUser); ?></strong></span>
                <a href="logout.php" class="header-btn">🚪 Logout</a>
            <?php else: ?>
                <a href="login.php" class="header-btn">🔑 Login</a>
            <?php endif; ?>
        </div>
    </header>
<div class="book-date-container">
    <div class="book-date-box <?php echo $partiallyBooked ? 'partial' : ($fullyBooked ? 'full' : ''); ?>">
        <div style="margin-bottom: 16px;">
            <a href="dashboard_admin.php" style="display:inline-block; color:#3498db; text-decoration:none; font-weight:600; font-size:0.95rem;">
                &larr; Back to Dashboard
            </a>
        </div>
         <h2>Book Date: <?php echo htmlspecialchars($date); ?></h2>

         <?php if ($error): ?>
             <div class="error"><?php echo $error; ?></div>
         <?php endif; ?>

         <!-- simple status indicator -->
         <div class="booked-info" id="bookedInfo" style="margin-bottom:12px;">
            <?php if ($fullyBooked): ?>
                <strong>Status:</strong> <span class="status-badge status-full">Fully Booked</span>
            <?php elseif ($partiallyBooked): ?>
                <strong>Status:</strong> <span class="status-badge status-partial">Partially Booked</span>
            <?php else: ?>
                <strong>Status:</strong> <span class="status-badge status-available">Available</span>
            <?php endif; ?>
        </div>

        <form method="POST" id="bookingWizard">
            <input type="hidden" name="overwrite" id="overwrite" value="0">
            <input type="hidden" name="delete_ids" id="delete_ids" value="">

            <!-- STEP 1: TIME SELECTION -->
            <div class="step" id="step1">
                <h3>Select Time</h3>
                <label>Start Time</label>
                <select name="start_time" id="start_time" required>
                    <option value="">Select start time</option>
                    <?php
                        $startHour = $isWeekend ? 5 : 8;
                        $endHour = 22;
                        for ($h = $startHour; $h < $endHour; $h++) {
                            $t = sprintf('%02d:00', $h);
                            $sel = ($t === $start) ? " selected" : "";
                            echo "<option value='$t'$sel>$t</option>";
                        }
                    ?>
                </select>
                <div id="startError" class="field-error">Please choose a start time.</div>

                <label style="margin-top: 8px;">End Time</label>
                <select name="end_time" id="end_time" required>
                    <?php
                    // Preselect end options if start chosen
                    if ($start) {
                        $startHourSelected = intval(explode(':', $start)[0]);
                        for ($h = $startHourSelected + 1; $h <= $endHour; $h++) {
                            $t = sprintf('%02d:00', $h);
                            $sel2 = ($t === $end) ? " selected" : "";
                            echo "<option value='$t'$sel2>$t</option>";
                        }
                    }
                    ?>
                </select>

                <div id="endError" class="field-error">Please choose an end time later than the start time.</div>

                <div class="button-group">
                    <button type="button" id="step1Next">Next</button>
                </div>
            </div>

            <!-- STEP 2: HOMEOWNER -->
            <div class="step" id="step2" style="display:none;">
                <h3>Are you a homeowner?</h3>
                    <div class="radio-group">
                        <label><input type="radio" name="is_homeowner" value="1" onclick="homeownerAlert(); updateElectricityNote()"> Yes</label>
                        <label><input type="radio" name="is_homeowner" value="0" onclick="updateElectricityNote()"> No</label>
                    </div>
                <div id="homeownerError" class="field-error">Please choose an option.</div>

                <div class="button-group">
                    <button type="button" onclick="prevStep()">Back</button>
                    <button type="button" id="step2Next">Next</button>
                </div>
            </div>

            <!-- STEP 3: NAME + REASON + ELECTRICITY -->
            <div class="step" id="step3" style="display:none;">
                <h3>Booker Information</h3>

                <label>Name</label>
                <input type="text" name="name" id="nameField" required>
                <div id="nameError" class="field-error">Please enter the booker's name.</div>

                <label style="margin-top: 8px;">Booking Reason</label>
                <select name="reason" id="reasonField" required>
                    <option value="">Choose Reason</option>
                    <option>SPORTS ACTIVITY</option>
                    <option>EVENT</option>
                    <option>OTHERS</option>
                </select>
                <div id="reasonError" class="field-error">Please select a reason.</div>

                <h3 style="margin-top:12px;">Add Electricity?</h3>
                <div class="radio-group">
                    <label><input type="radio" name="electricity" value="1" onclick="electricityAlert()"> Yes</label>
                    <label><input type="radio" name="electricity" value="0" checked> No</label>
                </div>
                <div id="electricityNote" style="margin-top:8px;font-size:0.95rem;color:#8a5d00;">Electricity has an additional fee.</div>

                <div class="button-group">
                    <button type="button" onclick="prevStep()">Back</button>
                    <button type="submit" id="finishBtn">Finish Booking</button>
                </div>

                <a href="dashboard_admin.php" class="back-inline">&larr; Back to Admin Dashboard</a>
            </div>

        </form>
    </div> <!-- end .book-date-box -->

    <!-- Booking status modal removed (dashboard admin now shows modal for partial/fully booked dates) -->

</div> <!-- end .book-date-container -->

<script>
    let currentStep = 1;

    // Helper: clear invalid states
    function clearInvalid(el) {
        if (!el) return;
        el.classList.remove('invalid');
        const err = document.getElementById(el.id + 'Error');
        if (err) err.style.display = 'none';
    }
    function setInvalid(el, msgId) {
        if (!el) return;
        el.classList.add('invalid');
        const err = document.getElementById(msgId);
        if (err) err.style.display = 'block';
    }

    function validateStep(step) {
        if (step === 1) {
            const start = document.getElementById('start_time');
            const end = document.getElementById('end_time');
            clearInvalid(start); clearInvalid(end);
            if (!start.value) { setInvalid(start, 'startError'); return false; }
            if (!end.value) { setInvalid(end, 'endError'); return false; }
            const sh = parseInt(start.value.split(':')[0],10);
            const eh = parseInt(end.value.split(':')[0],10);
            if (eh <= sh) { setInvalid(end, 'endError'); return false; }
            return true;
        }
        if (step === 2) {
            const home = document.querySelector('input[name="is_homeowner"]:checked');
            const errEl = document.getElementById('homeownerError');
            if (home) { errEl.style.display = 'none'; return true; }
            errEl.style.display = 'block';
            return false;
        }
        if (step === 3) {
            const name = document.getElementById('nameField');
            const reason = document.getElementById('reasonField');
            clearInvalid(name); clearInvalid(reason);
            let ok = true;
            if (!name.value.trim()) { setInvalid(name, 'nameError'); ok = false; }
            if (!reason.value) { setInvalid(reason, 'reasonError'); ok = false; }
            return ok;
        }
        return true;
    }

    document.getElementById('step1Next').addEventListener('click', function(){
        if (!validateStep(1)) return;
        nextStep();
    });
    document.getElementById('step2Next').addEventListener('click', function(){
        if (!validateStep(2)) return;
        nextStep();
    });

    document.getElementById('bookingWizard').addEventListener('submit', function(e){
        if (!validateStep(3)) { e.preventDefault(); return; }
    });

    function nextStep() {
        document.getElementById(`step${currentStep}`).style.display = "none";
        currentStep++;
        document.getElementById(`step${currentStep}`).style.display = "block";
    }
    function prevStep() {
        document.getElementById(`step${currentStep}`).style.display = "none";
        currentStep--;
        document.getElementById(`step${currentStep}`).style.display = "block";
    }

    function homeownerAlert() { alert("Reservation will be free for homeowners."); }
    function updateElectricityNote() {
        const home = document.querySelector('input[name="is_homeowner"]:checked');
        const note = document.getElementById('electricityNote');
        if (!note) return;
        if (home && home.value === '1') {
            note.style.display = 'none';
        } else {
            note.style.display = '';
        }
    }

    function electricityAlert() {
        const home = document.querySelector('input[name="is_homeowner"]:checked');
        if (home && home.value === '1') return; // homeowners skip electricity
        alert("Electricity has an additional fee. Do you want to continue?");
    }

    // Bookings for this date
    const existingBookings = <?php
        // Reduce to start/end arrays
        $simple = array_map(function($b){ return ['start' => $b->startTime, 'end' => $b->endTime]; }, $dateBookings);
        echo json_encode($simple);
    ?>;

    function toMinutes(t) {
        const parts = t.split(':');
        return parseInt(parts[0],10)*60 + (parseInt(parts[1]||'0',10));
    }

    function overlaps(aStart, aEnd, bStart, bEnd) {
        return !(aEnd <= bStart || aStart >= bEnd);
    }

    // Disable start options inside existing bookings
    function disableBookedStartOptions() {
        const startSelect = document.getElementById('start_time');
        if (!startSelect) return;
        for (let i=0;i<startSelect.options.length;i++) {
            const opt = startSelect.options[i];
            if (!opt.value) continue;
            let optMin = toMinutes(opt.value);
            let disabled = false;
            for (const b of existingBookings) {
                const bs = toMinutes(b.start);
                const be = toMinutes(b.end);
                if (optMin >= bs && optMin < be) { disabled = true; break; }
            }
            opt.disabled = disabled;
            opt.title = disabled ? 'This start time is already booked' : '';
        }
    }

    // Update end options avoiding overlaps
    document.getElementById("start_time").addEventListener("change", function() {
        const start = this.value;
        const endSelect = document.getElementById("end_time");
        endSelect.innerHTML = "";
        clearInvalid(this); clearInvalid(endSelect);
        if (!start) return;
        const startHour = parseInt(start.split(":")[0], 10);
        const maxHour = 22;
        for (let h = startHour + 1; h <= maxHour; h++) {
            const t = (h < 10 ? "0" : "") + h + ":00";
            // Check interval overlap
            const aStart = toMinutes(start);
            const aEnd = toMinutes(t);
            let ok = true;
            for (const b of existingBookings) {
                const bs = toMinutes(b.start);
                const be = toMinutes(b.end);
                if (overlaps(aStart, aEnd, bs, be)) { ok = false; break; }
            }
            if (ok) {
                endSelect.innerHTML += `<option value="${t}">${t}</option>`;
            }
        }
        // Show helpful option if no end options
        if (!endSelect.options.length) {
            endSelect.innerHTML = '<option value="">No available end times for this start</option>';
        }
    });

    // Disable booked start times on load
    disableBookedStartOptions();
    // Set electricity note visibility
    updateElectricityNote();

        // Receipt modal
        (function() {
            const bookingData = <?php echo isset($_SESSION['booking_success']) && $_SESSION['booking_success'] ? 'true' : 'false'; ?>;
            const summary = <?php echo isset($_SESSION['last_booking_summary']) ? json_encode($_SESSION['last_booking_summary']) : 'null'; ?>;
            if (bookingData && summary) {
                <?php $_SESSION['booking_success'] = false; ?>
                showReceipt(summary);
            }
        })();

        function showReceipt(summary) {
            const modal = document.getElementById('receiptModal');
            const content = document.getElementById('receiptContent');
            if (!modal || !content) return;

            const startHour = parseInt(summary.start.split(':')[0], 10);
            const endHour = parseInt(summary.end.split(':')[0], 10);
            const isHomeowner = summary.isHomeowner || false;
            const hasElectricity = summary.electricity || false;
            const dateObj = new Date(summary.date + 'T00:00:00');
            const isSaturday = dateObj.getDay() === 6;
            const morningCutoff = isSaturday ? 5 : 8;

            let morningStart = Math.max(morningCutoff, startHour);
            let morningEnd = Math.min(17, endHour);
            let morningHours = Math.max(0, morningEnd - morningStart);

            let eveningStart = Math.max(17, startHour);
            let eveningEnd = Math.min(22, endHour);
            let eveningHours = Math.max(0, eveningEnd - eveningStart);

            let morningRate = isHomeowner ? 0 : 75;
            if (!isHomeowner && hasElectricity) morningRate += 25;
            let eveningRate = isHomeowner ? 200 : 250;

            let morningCost = morningHours * morningRate;
            let eveningCost = eveningHours * eveningRate;
            let totalCost = morningCost + eveningCost;

            let html = `
                <div class="receipt-line">
                    <span class="receipt-line-label">Booked On</span>
                    <span class="receipt-line-value">${escapeHtml(summary.booked_at)}</span>
                </div>
                <div class="receipt-line">
                    <span class="receipt-line-label">Date</span>
                    <span class="receipt-line-value">${escapeHtml(summary.date)}</span>
                </div>
                <div class="receipt-line">
                    <span class="receipt-line-label">Time</span>
                    <span class="receipt-line-value">${escapeHtml(summary.start)} - ${escapeHtml(summary.end)}</span>
                </div>
                <div class="receipt-line">
                    <span class="receipt-line-label">Booker Name</span>
                    <span class="receipt-line-value">${escapeHtml(summary.name)}</span>
                </div>
                <div class="receipt-line">
                    <span class="receipt-line-label">Booking Reason</span>
                    <span class="receipt-line-value">${escapeHtml(summary.reason)}</span>
                </div>
                <div class="receipt-section">
                    <div class="receipt-section-title">Rate Breakdown</div>
            `;

            if (morningHours > 0) {
                const notes = isHomeowner ? ' (Homeowner)' : (hasElectricity ? ' (+ Electricity)' : '');
                html += `
                    <div class="receipt-line" style="font-size: 0.95rem;">
                        <span class="receipt-line-label">Morning (${isSaturday ? '05:00' : '08:00'}-17:00): ${morningHours}h @ ₱${morningRate}/hr${notes}</span>
                        <span class="receipt-line-value">₱${morningCost.toFixed(2)}</span>
                    </div>
                `;
            }

            if (eveningHours > 0) {
                const notes = isHomeowner ? ' (Homeowner)' : '';
                html += `
                    <div class="receipt-line" style="font-size: 0.95rem;">
                        <span class="receipt-line-label">Evening (17:00-22:00): ${eveningHours}h @ ₱${eveningRate}/hr${notes}</span>
                        <span class="receipt-line-value">₱${eveningCost.toFixed(2)}</span>
                    </div>
                `;
            }

            html += `
                </div>
                <div class="receipt-total">
                    <span class="receipt-total-label">Total Due</span>
                    <span class="receipt-total-amount">₱${totalCost.toFixed(2)}</span>
                </div>
            `;

            if (isHomeowner) {
                html += `<div class="receipt-note">ℹ️ <strong>Homeowner Booking:</strong> Morning hours are free. Evening rate: ₱200/hr.</div>`;
            }

            content.innerHTML = html;
            modal.classList.add('show');
            modal.setAttribute('aria-hidden', 'false');
        }

        function continueFromReceipt() {
            const modal = document.getElementById('receiptModal');
            if (modal) {
                modal.classList.remove('show');
                modal.setAttribute('aria-hidden', 'true');
            }
            // After booking: redirect to pricing_info
            window.location.href = 'pricing_info.php';
        }

        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

    // Overwrite confirmation
    function confirmOverwrite() {
        const confirmed = window.confirm(
            'WARNING: This will delete ALL existing bookings for this date.\n\n' +
            'Do you want to proceed?\n\n' +
            '(This action cannot be undone)'
        );

        if (!confirmed) return; // Cancelled

        const date = '<?php echo addslashes($date); ?>';
        const bookingModal = document.getElementById('bookingModal');
        const container = document.querySelector('.book-date-container');

        // AJAX: delete all for date
        const form = new FormData();
        form.append('action', 'delete_all');
        form.append('date', date);

        fetch(window.location.href, { method: 'POST', body: form, credentials: 'same-origin' })
            .then(r => r.json())
            .then(data => {
                if (data && data.success) {
                    // Close modals
                    if (bookingModal) {
                        bookingModal.style.display = 'none';
                        if (container) container.classList.remove('modal-open');
                    }
                    document.body.classList.remove('modal-open');
                    document.body.style.overflow = '';

                    // Update status
                    const bookedInfo = document.getElementById('bookedInfo');
                    if (bookedInfo) {
                        bookedInfo.innerHTML = '<strong>Status:</strong> <span class="status-badge status-available">Available</span>';
                    }

                    // Reset form
                    document.getElementById('step2').style.display = 'none';
                    document.getElementById('step3').style.display = 'none';
                    document.getElementById('step1').style.display = 'block';
                    currentStep = 1;

                    // Clear fields
                    document.getElementById('start_time').value = '';
                    document.getElementById('end_time').innerHTML = '';
                    document.querySelector('input[name="is_homeowner"]').checked = false;
                    document.getElementById('nameField').value = '';
                    document.getElementById('reasonField').value = '';
                    document.querySelector('input[name="electricity"][value="0"]').checked = true;

                    alert('✓ All bookings deleted. You may now book a new time slot.');
                } else {
                    alert('Error deleting bookings: ' + (data.error || 'Unknown error'));
                }
            })
            .catch(err => {
                console.error('AJAX error:', err);
                alert('AJAX error: ' + err.message);
            });
    }
</script>

<!-- full-width site footer (matches dashboard) -->
<footer class="site-footer" role="contentinfo">
     <div class="footer-left">
         <img src="assets/logo.png" alt="Marigold Logo">
         <div>
             <div class="sub-name">Marigold Subdivision</div>
             <div class="address">Phase 1 Marigold Subdivision Burgos, Rodriguez, Rizal.</div>
             <div class="contact">Contact: <a href="tel:0962620781" style="color:var(--primary);text-decoration:none;">0962620781</a></div>
         </div>
     </div>
    <div class="footer-links" aria-label="Footer links">
        <!-- Footer links removed on book_date.php per request -->
    </div>
</footer>

<!-- Receipt Modal -->
<div class="receipt-modal-overlay" id="receiptModal" aria-hidden="true" role="dialog" aria-modal="true">
    <div class="receipt-modal-box" role="document">
        <div class="receipt-header">
            <h2>✓ BOOKING CONFIRMED</h2>
            <p>Official Receipt</p>
        </div>
        <div class="receipt-content" id="receiptContent">
            <!-- Receipt details populated by JS -->
        </div>
        <div class="receipt-actions">
            <button class="receipt-btn receipt-btn-print" onclick="window.print()" aria-label="Print receipt">🖨️ Print</button>
            <button class="receipt-btn receipt-btn-continue" onclick="continueFromReceipt()" aria-label="Continue">Continue →</button>
        </div>
    </div>
</div>

</body>
</html>