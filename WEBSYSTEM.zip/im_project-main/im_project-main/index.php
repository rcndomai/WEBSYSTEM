<?php
// Redirect
header('Location: dashboard.php');
exit;
?>