<?php
class Auth {
	private $db;
	private $lastError = '';

	public function __construct() {
		// Session start
		if (session_status() === PHP_SESSION_NONE) {
			session_start();
		}
		$this->db = $this->getDatabase();
	}

	// DB connect
	private function getDatabase() {
		$host = 'localhost';
		$user = 'root';
		$password = '';
		$database = 'marigold_court';

		$conn = new mysqli($host, $user, $password, $database);
		if ($conn->connect_error) {
			$this->lastError = 'Database connection failed: ' . $conn->connect_error;
			return null;
		}
		$conn->set_charset('utf8mb4');
		return $conn;
	}

	public function getLastError() {
		return $this->lastError;
	}

	// Login (legacy compatible)
	public function login($username, $password) {
		$this->lastError = '';

		if (empty($username) || empty($password)) {
			$this->lastError = 'Username and password required.';
			return false;
		}
		if (!$this->db) {
			$this->lastError = 'No database connection.';
			return false;
		}

		$stmt = $this->db->prepare('SELECT id, username, password_hash, role, is_active FROM users WHERE username = ? LIMIT 1');
		if (!$stmt) {
			$this->lastError = 'DB prepare failed: ' . $this->db->error;
			return false;
		}
		$stmt->bind_param('s', $username);
		if (!$stmt->execute()) {
			$this->lastError = 'DB execute failed: ' . $stmt->error;
			$stmt->close();
			return false;
		}
		$res = $stmt->get_result();
		if ($res->num_rows === 0) {
			$this->lastError = 'Invalid username or password.';
			$stmt->close();
			return false;
		}
		$user = $res->fetch_assoc();
		$stmt->close();

		if (isset($user['is_active']) && !$user['is_active']) {
			$this->lastError = 'Account inactive.';
			return false;
		}

		$stored = (string)($user['password_hash'] ?? '');
		$ok = false;

		// Try password_verify
		if ($stored !== '' && (substr($stored,0,4) === '$2y$' || substr($stored,0,4) === '$2a$' || substr($stored,0,7) === '$argon2' || password_get_info($stored)['algo'] !== 0)) {
			if (password_verify($password, $stored)) {
				$ok = true;
				// Rehash if algorithm changed
				if (password_needs_rehash($stored, PASSWORD_DEFAULT)) {
					$this->rehashPassword($user['id'], $password);
				}
			}
		}

		// Fallback: plaintext
		if (!$ok && $stored === $password) {
			$ok = true;
			$this->rehashPassword($user['id'], $password);
		}

		// Fallback: md5
		if (!$ok && strlen($stored) === 32 && md5($password) === $stored) {
			$ok = true;
			$this->rehashPassword($user['id'], $password);
		}

		// Fallback: sha1
		if (!$ok && strlen($stored) === 40 && sha1($password) === $stored) {
			$ok = true;
			$this->rehashPassword($user['id'], $password);
		}

		if (!$ok) {
			$this->lastError = 'Invalid username or password.';
			return false;
		}

		// Set session on success
		$_SESSION['user_id'] = (int)$user['id'];
		$_SESSION['username'] = $user['username'];

		// Determine role and check super_admin override
		$sessionRole = $user['role'] ?? null;
		if ($this->db) {
			$stmtSuper = $this->db->prepare("SELECT username FROM users WHERE role = 'super_admin' LIMIT 1");
			if ($stmtSuper) {
				$stmtSuper->execute();
				$resSuper = $stmtSuper->get_result();
				if ($resSuper && ($rowSuper = $resSuper->fetch_assoc())) {
					$superUsername = $rowSuper['username'] ?? null;
					if ($superUsername !== null && strcasecmp($superUsername, $user['username']) === 0) {
						$sessionRole = 'super_admin';
					}
				}
				$stmtSuper->close();
			}
		}

		$_SESSION['role'] = $sessionRole;

		return true;
	}

	/**
	 * Replace stored password with secure hash
	 */
	private function rehashPassword($userId, $plainPassword) {
		if (!$this->db) return;
		$hash = password_hash($plainPassword, PASSWORD_DEFAULT);
		$stmt = $this->db->prepare('UPDATE users SET password_hash = ?, updated_at = NOW() WHERE id = ?');
		if ($stmt) {
			$stmt->bind_param('si', $hash, $userId);
			$stmt->execute();
			$stmt->close();
		}
	}

	public function isLoggedIn() {
		return isset($_SESSION['user_id']) && isset($_SESSION['role']);
	}

	public function getRole() {
		return $_SESSION['role'] ?? null;
	}

	public function getUserId() {
		return $_SESSION['user_id'] ?? null;
	}

	public function getUsername() {
		return $_SESSION['username'] ?? null;
	}

	public function logout() {
		$_SESSION = [];
		if (ini_get("session.use_cookies")) {
			$params = session_get_cookie_params();
			setcookie(session_name(), '', time() - 42000,
				$params["path"], $params["domain"],
				$params["secure"], $params["httponly"]
			);
		}
		session_destroy();
		header('Location: login.php');
		exit;
	}
}
?>