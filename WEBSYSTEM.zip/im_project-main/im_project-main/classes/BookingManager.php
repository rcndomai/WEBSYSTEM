<?php
require_once "Booking.php";

class BookingManager {
    private $db;

    public function __construct() {
        $this->db = $this->getDatabase();
    }

    private function getDatabase() {
        $host = 'localhost';
        $user = 'root';
        $password = '';
        $database = 'marigold_court';

        $conn = new mysqli($host, $user, $password, $database);
        if ($conn->connect_error) {
            die('Database connection failed: ' . $conn->connect_error);
        }
        $conn->set_charset('utf8mb4');
        return $conn;
    }

    // Activity channel (local log)
    private function writeActivityChannel($message) {
        try {
            $logDir = __DIR__ . '/../logs';
            if (!is_dir($logDir)) @mkdir($logDir, 0755, true);
            $file = $logDir . '/activity_channel.log';
            $line = '[' . date('Y-m-d H:i:s') . '] ' . $message . PHP_EOL;
            @file_put_contents($file, $line, FILE_APPEND | LOCK_EX);
        } catch (Exception $e) {
            // ignore
        }
    }

    // Get bookings
    public function getBookings() {
        if (!$this->db) return [];
        
        $stmt = $this->db->prepare('SELECT id, date, start_time, end_time, name, is_paid, reason, is_homeowner, electricity FROM bookings ORDER BY date ASC, start_time ASC');
        if (!$stmt) return [];
        
        $stmt->execute();
        $result = $stmt->get_result();
        $bookings = [];
        
        while ($row = $result->fetch_assoc()) {
            $booking = new Booking($row['date'], $row['start_time'], $row['end_time'], $row['name'], $row['is_paid'], $row['reason'], $row['is_homeowner'], $row['electricity']);
            $booking->id = $row['id'];
            $bookings[] = $booking;
        }
        $stmt->close();
        return $bookings;
    }

    // Check slot availability
    public function isSlotAvailable($date, $start, $end) {
        if (!$this->db) return false;
        
        $stmt = $this->db->prepare('SELECT COUNT(*) as count FROM bookings WHERE date = ? AND NOT (end_time <= ? OR start_time >= ?)');
        if (!$stmt) return false;
        
        $stmt->bind_param('sss', $date, $start, $end);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        $stmt->close();
        
        return $row['count'] == 0;
    }

    // Add booking
    public function addBooking(Booking $booking) {
        if (!$this->db) return false;
        
        $stmt = $this->db->prepare('INSERT INTO bookings (date, start_time, end_time, name, is_paid, reason, is_homeowner, electricity) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
        if (!$stmt) return false;
        
        $date = $booking->date;
        $start_time = $booking->startTime;
        $end_time = $booking->endTime;
        $name = $booking->name;
        $is_paid = $booking->isPaid ?? 0;
        $reason = $booking->reason;
        $is_homeowner = $booking->isHomeowner ?? 0;
        $electricity = $booking->electricity ?? 0;
        
        $stmt->bind_param('ssssisii', $date, $start_time, $end_time, $name, $is_paid, $reason, $is_homeowner, $electricity);
        $success = $stmt->execute();
        $stmt->close();
        
        return $success;
    }

    // Delete booking
    public function deleteBooking($id) {
        if (!$this->db) return false;
        
        $stmt = $this->db->prepare('DELETE FROM bookings WHERE id = ?');
        if (!$stmt) return false;
        
        $stmt->bind_param('i', $id);
        $success = $stmt->execute();
        $stmt->close();
        
        return $success;
    }

    // Delete bookings by date
    public function deleteBookingsByDate($date) {
        if (!$this->db) return false;

        // fetch ids then delete individually
        $ids = [];
        $s = $this->db->prepare('SELECT id FROM bookings WHERE date = ?');
        if ($s) {
            $s->bind_param('s', $date);
            $s->execute();
            $res = $s->get_result();
            while ($row = $res->fetch_assoc()) {
                $ids[] = (int)$row['id'];
            }
            $s->close();
        }

        $allOk = true;
        foreach ($ids as $id) {
            $ok = $this->deleteBookingByUser($id, null);
            if (!$ok) $allOk = false;
        }

        return $allOk;
    }

    // Alias: removeBookingsForDate
    public function removeBookingsForDate($date) {
        return $this->deleteBookingsByDate($date);
    }

    // Alias: deleteAllByDate
    public function deleteAllByDate($date) {
        return $this->deleteBookingsByDate($date);
    }

    // Alias: deleteByDate
    public function deleteByDate($date) {
        return $this->deleteBookingsByDate($date);
    }

    // Alias: removeBookingById
    public function removeBookingById($id) {
        return $this->deleteBooking($id);
    }

    // Update paid status
    public function updateBookingPaid($id, $isPaid) {
        if (!$this->db) return false;
        
        $stmt = $this->db->prepare('UPDATE bookings SET is_paid = ? WHERE id = ?');
        if (!$stmt) return false;
        
        $isPaid = (int)$isPaid;
        $stmt->bind_param('ii', $isPaid, $id);
        $success = $stmt->execute();
        $stmt->close();
        
        return $success;
    }

    // Create booking (with activity log)
    public function createBookingByUser($userId, Booking $booking) {
        $success = $this->addBooking($booking);
        if ($success) {
            $bookingId = $this->db->insert_id;
            if ($bookingId) {
                // store snapshot in details
                $stmt = $this->db->prepare("INSERT INTO activity_log (booking_id, user_id, action, details) VALUES (?, ?, ?, ?)");
                if ($stmt) {
                    $action = 'booking_created';
                    $details = sprintf('Booking #%d created: %s %s-%s by %s', $bookingId, $booking->date, $booking->startTime, $booking->endTime, $booking->name);
                    $bookingRef = (int)$bookingId;
                    $uid = $userId !== null ? (int)$userId : 0;
                    $stmt->bind_param('iiss', $bookingRef, $uid, $action, $details);
                    $stmt->execute();
                    $stmt->close();
                    // also write to local channel
                    $this->writeActivityChannel($details);
                }
            }
        }
        return $success;
    }

    // Delete booking by user (with logging)
    public function deleteBookingByUser($id, $userId = null) {
        if (!$this->db) return false;

        // fetch snapshot
        $snapshot = null;
        $s = $this->db->prepare('SELECT date, start_time, end_time, name FROM bookings WHERE id = ?');
        if ($s) {
            $s->bind_param('i', $id);
            $s->execute();
            $res = $s->get_result();
            $snapshot = $res->fetch_assoc();
            $s->close();
        }

        // log deletion with snapshot
        $stmt2 = $this->db->prepare("INSERT INTO activity_log (booking_id, user_id, action, details) VALUES (?, ?, ?, ?)");
        if ($stmt2) {
            $action = 'booking_deleted';
            if ($snapshot) {
                // trim seconds if present
                $start = isset($snapshot['start_time']) ? (strlen($snapshot['start_time']) >= 5 ? substr($snapshot['start_time'],0,5) : $snapshot['start_time']) : '';
                $end = isset($snapshot['end_time']) ? (strlen($snapshot['end_time']) >= 5 ? substr($snapshot['end_time'],0,5) : $snapshot['end_time']) : '';
                $details = sprintf('Booking #%d deleted: %s %s-%s by %s', $id, $snapshot['date'], $start, $end, $snapshot['name']);
            } else {
                $details = sprintf('Booking #%d deleted', $id);
            }
            $bookingRef = (int)$id;
            $uid = $userId !== null ? (int)$userId : 0;
            $stmt2->bind_param('iiss', $bookingRef, $uid, $action, $details);
            $stmt2->execute();
            $stmt2->close();
            // append to local channel
            $this->writeActivityChannel($details);
        }

        // delete booking
        $stmt = $this->db->prepare('DELETE FROM bookings WHERE id = ?');
        if (!$stmt) return false;

        $stmt->bind_param('i', $id);
        $success = $stmt->execute();
        $stmt->close();

        return $success;
    }
}
?>