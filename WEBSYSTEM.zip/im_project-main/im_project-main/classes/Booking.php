<?php
class Booking {
    public $date;
    public $startTime;
    public $endTime;
    public $name;
    public $isPaid;
    public $reason;
    public $isHomeowner;
    public $electricity;
    public $totalPrice = 0;
    public $ratePerHour = 0;
    public $id;

    public function __construct($date, $startTime, $endTime, $name, $isPaid = 0, $reason = '', $isHomeowner = false, $electricity = false) {
        $this->date = $date;
        $this->startTime = $startTime;
        $this->endTime = $endTime;
        $this->name = $name;
        $this->isPaid = $isPaid;
        $this->reason = $reason;
        $this->isHomeowner = $isHomeowner;
        $this->electricity = $electricity;
        
        // Pricing
        $this->calculatePrice();
    }
    // Calculate price
    private function calculatePrice() {
        $start = strtotime('2000-01-01 ' . $this->startTime);
        $end = strtotime('2000-01-01 ' . $this->endTime);
        
        // Time bounds
        $morningStart = strtotime('2000-01-01 08:00');
        $eveningStart = strtotime('2000-01-01 17:00');
        $nightEnd = strtotime('2000-01-01 22:00');
        
        $totalPrice = 0.0;
        
        // Split periods (morning/evening)
        if ($start < $eveningStart && $end > $morningStart) {
            $morningStart_actual = max($start, $morningStart);
            $morningEnd_actual = min($end, $eveningStart);
            if ($morningStart_actual < $morningEnd_actual) {
                $morningHours = ($morningEnd_actual - $morningStart_actual) / 3600;
                if ($this->isHomeowner) {
                    $totalPrice += 0;
                } else {
                    $totalPrice += $morningHours * 75;
                }
            }
        }
        
        if ($start < $nightEnd && $end > $eveningStart) {
            $eveningStart_actual = max($start, $eveningStart);
            $eveningEnd_actual = min($end, $nightEnd);
            if ($eveningStart_actual < $eveningEnd_actual) {
                $eveningHours = ($eveningEnd_actual - $eveningStart_actual) / 3600;
                if ($this->isHomeowner) {
                    $totalPrice += $eveningHours * 200;
                } else {
                    $totalPrice += $eveningHours * 250;
                }
            }
        }
        
        // Electricity fee
        if ($this->electricity && !$this->isHomeowner) {
            $totalHours = ($end - $start) / 3600;
            $totalPrice += $totalHours * 25;
        }

        // Service fee
        $totalPrice += 50;

        $this->totalPrice = $totalPrice;
        $this->ratePerHour = 0;
    }
}
?>