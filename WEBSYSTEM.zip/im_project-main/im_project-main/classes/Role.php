<?php

class Role {
    // Constants
    const ROLE_ADMIN = 'admin';
    const ROLE_SECRETARY = 'secretary';
    const ROLE_USER = 'user';
    const ROLE_SUPER_ADMIN = 'super_admin';

    private $userRole;

    // Initialization
    public function __construct($role = null) {
        $this->userRole = $role;
    }

    // Accessors
    public function getRole() {
        return $this->userRole;
    }

    public function setRole($role) {
        $this->userRole = $role;
    }

    // Role checks
    public function isAdmin() { return $this->userRole === self::ROLE_ADMIN; }
    public function isSuperAdmin() { return $this->userRole === self::ROLE_SUPER_ADMIN; }
    public function isSecretary() { return $this->userRole === self::ROLE_SECRETARY; }
    public function isUser() { return $this->userRole === self::ROLE_USER; }

    // Permission helpers
    public function canManageBookings() { return $this->isSuperAdmin() || $this->isAdmin() || $this->isSecretary(); }
    public function canDeleteAll() { return $this->isSuperAdmin() || $this->isAdmin(); }
    public function canOverwrite() { return $this->isSuperAdmin() || $this->isAdmin(); }
    public function canViewBookings() { return $this->isSuperAdmin() || !is_null($this->userRole); }
    public function canCreateBooking() { return $this->isSuperAdmin() || $this->isAdmin() || $this->isSecretary(); }
    public function canEditBooking() { return $this->isSuperAdmin() || $this->isAdmin() || $this->isSecretary(); }
    public function canDeleteBooking() { return $this->isSuperAdmin() || $this->isAdmin() || $this->isSecretary(); }
    public function canManageUsers() { return $this->isSuperAdmin(); }
    public function canViewActivityLog() { return $this->isSuperAdmin() || $this->isAdmin(); }
    public function canViewFinanceReport() { return $this->isSuperAdmin() || $this->isAdmin(); }

    // Display & static helpers
    public function getRoleDisplayName() {
        switch ($this->userRole) {
            case self::ROLE_SUPER_ADMIN: return 'Super Admin';
            case self::ROLE_ADMIN: return 'Administrator';
            case self::ROLE_SECRETARY: return 'Secretary';
            case self::ROLE_USER: return 'User';
            default: return 'Guest';
        }
    }

    public static function getAllRoles() {
        return [ self::ROLE_SUPER_ADMIN, self::ROLE_ADMIN, self::ROLE_SECRETARY, self::ROLE_USER ];
    }

    public static function getAssignableRoles() { return [ self::ROLE_ADMIN, self::ROLE_SECRETARY ]; }

    public static function isValidRole($role) { return in_array($role, self::getAllRoles()); }
}
?>
