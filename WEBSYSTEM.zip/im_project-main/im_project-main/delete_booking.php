<?php
// Delete booking endpoint
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Session & role check
    if (session_status() === PHP_SESSION_NONE) session_start();
    require_once 'classes/Role.php';
    $role = $_SESSION['role'] ?? null;
    $userRole = new Role($role);

    // Permission: delete booking
    if (!$userRole->canDeleteBooking()) {
        http_response_code(403);
        echo 'Forbidden: insufficient permissions';
        exit;
    }

    require_once 'classes/db.php';
    $date = $_POST['date'] ?? '';
    $start = $_POST['start'] ?? '';
    $end = $_POST['end'] ?? '';
    $name = $_POST['name'] ?? '';
    if ($date && $start && $end && $name) {
        // Find booking id for logging
        $stmtFind = $pdo->prepare('SELECT id FROM bookings WHERE date = ? AND start_time = ? AND end_time = ? AND name = ? LIMIT 1');
        $stmtFind->execute([$date, $start, $end, $name]);
        $found = $stmtFind->fetch();
        $bookingId = $found['id'] ?? null;

        $stmt = $pdo->prepare('DELETE FROM bookings WHERE date = ? AND start_time = ? AND end_time = ? AND name = ? LIMIT 1');
        $stmt->execute([$date, $start, $end, $name]);

        // Log deletion
        $userId = $_SESSION['user_id'] ?? null;
        $action = 'booking_deleted';
        $details = 'Booking deleted';
        if ($userId) $details .= ' by user_id=' . (int)$userId;

        $stmtLog = $pdo->prepare('INSERT INTO activity_log (booking_id, user_id, action, details) VALUES (?, ?, ?, ?)');
        $stmtLog->execute([$bookingId, $userId, $action, $details]);

        echo 'OK';
        exit;
    }
    http_response_code(400);
    echo 'Missing data';
    exit;
}
http_response_code(405);
echo 'Method not allowed';
