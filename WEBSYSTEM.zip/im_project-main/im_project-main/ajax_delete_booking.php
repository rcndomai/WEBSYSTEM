<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once 'classes/Auth.php';
require_once 'classes/Role.php';
require_once 'classes/BookingManager.php';

$auth = new Auth();
if (!$auth->isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Not authenticated']);
    exit;
}
$role = new Role($auth->getRole());
if (!$role->canDeleteBooking()) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Forbidden']);
    exit;
}

$id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
if ($id <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Missing id']);
    exit;
}

$mgr = new BookingManager();
$userId = $_SESSION['user_id'] ?? null;
$ok = $mgr->deleteBookingByUser($id, $userId);

header('Content-Type: application/json');
echo json_encode(['success' => $ok]);
exit;
?>
